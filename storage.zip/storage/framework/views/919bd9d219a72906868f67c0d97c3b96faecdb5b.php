<?php $__env->startSection('content'); ?>
<!-- Page Heading -->
<?php if($errors->any()): ?>
<div class="alert alert-danger border-left-danger" role="alert">
    <ul class="pl-4 my-2">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>

<div class="card shadow mb-4">

    <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel"><?php echo e(__('Tambah Lokasi')); ?></h5>
    </div>

    <form method="POST" action="<?php echo e(route('hrd.MstLokasi.store')); ?>" autocomplete="off">
        <?php echo e(csrf_field()); ?>

        <div class="modal-body">

            <div class="row">

                <div class="col-lg-12 order-lg-4">

                    <div class="card-body">

                        <div class="row">

                            <div class="col-lg-12">
                                <div class="form-group focused">
                                    <label class="form-control-label" for="nama">Nama Kantor<span
                                            class="small text-danger">*</span>
                                    </label>
                                    <input type="text" id="nama" class="form-control" name="nama" placeholder="Nama"
                                        required="">

                                    <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                        </div>
                        <div class="row">

                            <div class="col-lg-12">
                                <div class="form-group focused">
                                    <label class="form-control-label" for="alamat">Alamat<span
                                            class="small text-danger">*</span>
                                    </label>
                                    <input type="text" id="alamat" class="form-control" name="alamat"
                                        placeholder="Alamat" required="">

                                    <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                        </div>

                        <div class="row">

                            <div class="col-lg-6">
                                <div class="form-group focused">
                                    <label class="form-control-label" for="latitude">Latitude<span
                                            class="small text-danger">*</span>
                                    </label>
                                    <input type="text" id="latitude" class="form-control" name="latitude"
                                        placeholder="Latitude" required="">

                                    <?php $__errorArgs = ['latitude'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group focused">
                                    <label class="form-control-label" for="longitude">Longitude<span
                                            class="small text-danger">*</span>
                                    </label>
                                    <input type="text" id="longitude" class="form-control" name="longitude"
                                        placeholder="Latitude" required="">

                                    <?php $__errorArgs = ['longitude'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>

        </div>
        <div class="modal-footer">
            <a href="<?php echo e(route('hrd.MstLokasi.index')); ?>" class="btn btn-link"><?php echo e(__('Kembali')); ?></a>
            <button type="submit" class="btn btn-primary"><?php echo e(__('Simpan')); ?></button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', ['title' => 'Lokasi'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\yazfi\resources\views/hrd/mst_lokasi/create.blade.php ENDPATH**/ ?>