<div class="row">
    <div class="col-md-12">
        <div class="table-responsive">
            <table class="table table-striped table-bordered custom-table report" width="100%">
                <thead>
                    <tr>
                        <th style="text-align: center;">No</th>
                        <th>Nama Item</th>
                        <th>Supllier</th>
                        <th>Customer</th>
                        
                        <th>In</th>
                        <th>Out</th>
                        <th>Last Stok</th>
                        <th>Waktu</th>
                        <th>Admin</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $barangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td style="text-align: center;"><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($barang->barang->nama_barang); ?></td>
                        <td><?php echo e($barang->supplier->nama ?? '-'); ?></td>
                        <td>
                            <?php if($barang->customer_id): ?>
                            <?php echo e($barang->customer->nama); ?>

                            <?php endif; ?>
                            <?php if($barang->cabang_id): ?>
                            <?php echo e($barang->cabang->nama); ?>

                            <?php endif; ?>
                        </td>
                        
                        <td><?php echo e($barang->in ?? '-'); ?></td>
                        <td><?php echo e($barang->out ?? '-'); ?></td>
                        <td><?php echo e($barang->last_stok ?? '-'); ?></td>
                        <td><?php echo e(Carbon\Carbon::parse($barang->created_at)->format('d/m/Y H:i:s')); ?></td>
                        <td><?php echo e($barang->admin->name); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot>
                    <tr>
                        <td>Total : </td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td><?php echo e($barangs->sum('last_stok') - ($barang->sum('out') + $barangs->sum('in')) ?? 0); ?></td>
                        <td><?php echo e($barangs->sum('in') ?? 0); ?></td>
                        <td><?php echo e($barangs->sum('out') ?? 0); ?></td>
                        <td><?php echo e($barangs->sum('last_stok') ?? 0); ?></td>
                        <td></td>
                        <td></td>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\yazfi\resources\views/hrd/report/barang/table.blade.php ENDPATH**/ ?>