

<?php $__env->startSection('content'); ?>
<div class="row justify-content-left text-left">
    <div class="col-md-6">
        <h4 class="page-title">Add Team Sales</h4>
    </div>
</div>

<form action="<?php echo e(route('hrd.sales.store')); ?>" method="post" enctype="multipart/form-data">
    <?php if(session()->has('error')): ?>
    <div class="alert alert-danger">
        <?php echo e(session()->get('error')); ?>

        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span
            aria-hidden="true">&times;</span></button>
    </div>
    <?php endif; ?>
    <?php echo csrf_field(); ?>
    <?php echo $__env->make('hrd.sales.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<script>
    $(".select2").select2()

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', ['title' => 'Add Team Sales'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\yazfi\resources\views/hrd/sales/create.blade.php ENDPATH**/ ?>