

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-sm-4 col-3">
        <h4 class="page-title">Add Kategori Barang</h4>
    </div>
</div>

<form action="<?php echo e(route('admin.kategori-barang.store')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php echo $__env->make('admin.kategori-barang.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', ['title' => 'Kategori Barang'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\yazfi\resources\views/admin/kategori-barang/create.blade.php ENDPATH**/ ?>