

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-sm-4 col-3">
        <h4 class="page-title">Team Sales</h4>
    </div>
    <div class="col-sm-8 col-9 text-right m-b-20">
        <a href="<?php echo e(route('hrd.sales.create')); ?>" class="btn btn btn-primary btn-rounded float-right"><i
                class="fa fa-plus"></i> Add Team Sales</a>

    </div>
</div>
 <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.alert','data' => []]); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<div class="row">
    <div class="col-sm-12">
        <div class="table-responsive">
            <table class="table custom-table table-striped report" width="100%">
                <thead>
                    <tr>
                        <th class="text-center">No</th>
                        <th>Manager</th>
                        <th>Supervisor</th>
                        <th>Sales</th>
                        <th>Action</th>
                    </tr>
                </thead>


                <tbody>
                  
                    <?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $man): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th class="text-center"><?php echo e($loop->iteration); ?></th>
                        <th><?php echo e($man->manager->name); ?></th>
                        <th><?php echo e($man->spv->name); ?></th>
                        
                        <?php $__currentLoopData = $sale; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th>
                            <?php $__currentLoopData = $sal->sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span class="custom-badge status-blue"><?php echo e($pur->user->name); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <th>
                            <a href="<?php echo e(route('hrd.sales.edit', $man->user_id)); ?>" class="btn btn-sm btn-info"><i
                                    class="fa fa-edit"></i></a>
                            <a href="<?php echo e(route('hrd.sales.hapus', $man->user_id)); ?>" class=" btn btn-sm btn-danger"><i
                                    class="fa fa-trash"></i></a>
                        </th>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>

<script>
    $('.report').DataTable({
        dom: 'Bfrtip',
        buttons: [{
                extend: 'copy',
                className: 'btn-default',
                exportOptions: {
                    columns: ':visible'
                }
            },
            {
                extend: 'excel',
                className: 'btn-default',
                title: 'Laporan Team Sales ',
                messageTop: 'Tanggal  <?php echo e(request("from")); ?> - <?php echo e(request("to")); ?>',
                footer: true,
                exportOptions: {
                    columns: ':visible'
                }
            },
            {
                extend: 'pdf',
                className: 'btn-default',
                title: 'Laporan Team Sales ',
                messageTop: 'Tanggal <?php echo e(request("from")); ?> - <?php echo e(request("to")); ?>',
                footer: true,
                exportOptions: {
                    columns: ':visible'
                }
            },
        ]
    });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', ['title' => 'Master User'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\yazfi\resources\views/hrd/sales/index.blade.php ENDPATH**/ ?>