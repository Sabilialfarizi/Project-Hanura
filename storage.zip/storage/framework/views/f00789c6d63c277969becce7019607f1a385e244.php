
<?php $__env->startSection('content'); ?>
<div class="row justify-content-center text-center">
    <div class="col-sm-4 col-3">
        <h4 class="page-title">Edit Rincian Gaji</h4>
    </div>
</div>
<div class="row justify-content-center">
    <div class="col-sm-6">
        <form action="<?php echo e(route('hrd.rincianpenggajian.update', $gajian->id)); ?>" method="post" id="form">
            <?php echo csrf_field(); ?>
            <?php echo method_field('put'); ?>
            <div class="row">
                <div class="col-md-12">
                    <div class="card shadow" id="card">
                        <div class="card-body">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="id_role">Nama Roles </label>
                                    <select name="id_role" id="roles" class="form-control">
                                        
                                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option <?php echo e($gajian->id_role == $role->id ? 'selected' : ''); ?>

                                            value="<?php echo e($role->id); ?>">
                                            <?php echo e($role->key); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>

                                    <?php $__errorArgs = ['id_role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="text-danger"><?php echo e($message); ?></small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>


                                <div class="form-group">
                                    <label for="gaji">Gaji</label>
                                    <input type="text" id="gaji" required="" name="gaji"
                                        value="<?php echo e($gajian ? $gajian->gaji : ''); ?>" class="form-control">

                                    <?php $__errorArgs = ['gaji'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="text-danger"><?php echo e($message); ?></small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>


                                <div class="form-group">
                                    <div class="col-sm-1 offset-sm-0">
                                        <button type="submit" class="btn btn-primary" id="submit">Submit</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', ['title' => 'Edit Rincian Gaji'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\yazfi\resources\views/hrd/rincianpenggajian/edit.blade.php ENDPATH**/ ?>