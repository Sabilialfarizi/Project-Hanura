<div class="row">
    <div class="col-md-12">
        <div class="card shadow" id="card">
            <div class="card-body">

                <div class="form-group">
                    <label>Name</label>
                    <input type="text" name="name" id="name" class="form-control" value="<?php echo e($permission->key); ?>">
                </div>

                <div class="m-t-20 text-center">
                    <button type="submit" class="btn btn-primary submit-btn"><i class="fa fa-save"></i> Save</button>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\yazfi\resources\views/hrd/permission/form.blade.php ENDPATH**/ ?>