

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center text-center">
    <div class="col-md-6">
        <h1 class="page-title">Edit Roles</h1>
    </div>
</div>

<div class="row justify-content-center">
    <div class="col-md-6">
        <form action="<?php echo e(route('hrd.permission.update', $permission->id)); ?>" method="post">
            <?php echo method_field('PATCH'); ?>
            <?php echo csrf_field(); ?>
            <?php echo $__env->make('hrd.permission.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', ['title' => 'Roles'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\yazfi\resources\views/hrd/permission/edit.blade.php ENDPATH**/ ?>