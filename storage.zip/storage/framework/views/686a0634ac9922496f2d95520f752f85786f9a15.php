
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-sm-5 col-4">
        <h4 class="page-title">Show Penerimaan Barang</h4>
    </div>
   
</div>
<div class="container">
    <div class="row">
        <div class="col-md-12 col-md-offset-3 body-main">
            <div class="col-md-12">
                <div class="card shadow" id="card">
                    <div class="card-body">
                        
                        <div class="row">
                            <div class="col-md-12">
                                <div class="table-responsive">
                                    <table class="table table-bordered table-striped custom-table report">
                                        <tr style="font-size:12px;" class="bg-success">
                                            <th class="text-light">No.</th>
                                            <th class="text-light">Nomor PN</th>
                                            <th class="text-light">Nomor PO</th>
                                            <th class="text-light">Nama Barang</th>
                                            <th class="text-light">Unit</th>
                                            <th class="text-light">Warehouse</th>
                                            <th class="text-light">Status Barang</th>
                                            <th class="text-light">Qty</th>
                                            <th class="text-light">Qty Received</th>
                                            <th class="text-light">Harga Beli</th>
                                        </tr>
                                        <tbody>
                                            <?php
                                            $total = 0
                                            ?>
                                            <?php $__currentLoopData = App\PenerimaanBarang::where('no_penerimaan_barang', $penerimaan->no_penerimaan_barang)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr style="font-size:12px;">
                                               
                                                <td><?php echo e($loop->iteration); ?></td>
                                                <td><?php echo e($barang->no_penerimaan_barang); ?></td>
                                                <td><?php echo e($barang->no_po); ?></td>
                                                <td><?php echo e($barang->barang->nama_barang); ?></td>
                                                <td><?php echo e($barang->purchase->unit); ?></td>
                                                <td><?php echo e($barang->purchase->warehouse->nama_warehouse); ?></td>
                                                <td>
                                                    <div class="d-flex justify-content-center mt-2">
                                                        <?php if($barang->qty != $barang->qty_received): ?>
                                                        <span class="custom-badge status-orange">partial</span>
                                                        <?php endif; ?>
                                                        <?php if($barang->qty == $barang->qty_received): ?>
                                                        <span class="custom-badge status-green">completed</span>
                                                        <?php endif; ?>
                                                    </div>
                                                </td>
                                                <td><?php echo e($barang->qty); ?></td>
                                                <td><?php echo e($barang->qty_received); ?></td>
                                                
                                                <td>Rp. <?php echo number_format($barang->harga_beli, 0, ',', '.'); ?></td>
                                              
                                                
                                            </tr>
                                            <?php
                                            $total += $barang->qty_received * $barang->harga_beli
                                            ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <td rowspan="2  " colspan="2"><b>Total Pembelian : </b></td>
                                              
                                            </tr>
                                            <tr style="font-size:12px;">
                                                <td colspan="5"></td>
                                                <td>SUB TOTAL </td>
                                                <td><b>Rp. <?php echo number_format($total, 0, ',', '.'); ?></b></td>
                                            </tr>
                                            <tr style="font-size:12px;">
                                                <td colspan="7"></td>
                                                <td>PPN</td>
                                                <td><b><?php echo e($penerimaan->ppn); ?>%</b></td>
                                            </tr>
                                            <tr style="font-size:12px;">
                                                <td colspan="7"></td>
                                                <td><strong>TOTAL<strong> </td>
                                                <td><b>Rp. <?php echo number_format($penerimaan->grandtotal, 0, ',', '.'); ?></b></td>
                                            </tr>
                                        </tfoot>
                                       
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer'); ?>
<script>
    $('.report').DataTable({
        dom: 'Bfrtip',
        buttons: [{
                extend: 'copy',
                className: 'btn-default',
                exportOptions: {
                    columns: ':visible'
                }
            },
            {
                extend: 'excel',
                className: 'btn-default',
                title: 'Laporan Pembelian ',
                messageTop: 'Tanggal  <?php echo e(request("from")); ?> - <?php echo e(request("to")); ?>',
                footer: true,
                exportOptions: {
                    columns: ':visible'
                }
            },
            {
                extend: 'pdf',
                className: 'btn-default',
                title: 'Laporan Pembelian ',
                messageTop: 'Tanggal <?php echo e(request("from")); ?> - <?php echo e(request("to")); ?>',
                footer: true,
                exportOptions: {
                    columns: ':visible'
                }
            },
        ]
    });

</script>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.master', ['title' => 'Show Purchase'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\yazfi\resources\views/purchasing/penerimaan-barang/show.blade.php ENDPATH**/ ?>