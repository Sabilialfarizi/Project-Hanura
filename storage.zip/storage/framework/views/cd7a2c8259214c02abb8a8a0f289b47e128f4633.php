

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-sm-12">
        <h4 class="page-title">Report Komisi</h4>
    </div>
</div>

<form action="<?php echo e(route('admin.report.komisi')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <div class="row filter-row">
        <div class="col-sm-6 col-md-3">
            <div class="form-group form-focus select-focus focused">
                <label class="focus-label">Pegawai</label>
                <select name="pegawai" class="select floating select2" tabindex="-1" aria-hidden="true">
                    <option disabled selected>Select Pegawai</option>
                    <option <?php echo e(request('pegawai') == 'all' ? 'selected' : ''); ?> value="all">Semua Pegawai</option>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option <?php echo e(request('pegawai') == $user->id ? 'selected' : ''); ?> value="<?php echo e($user->id); ?>" required><?php echo e($user->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>

        <div class="col-sm-6 col-md-3">
            <div class="form-group form-focus">
                <label class="focus-label">From</label>
                <div class="cal-icon">
                    <input class="form-control floating datetimepicker" type="text" name="from" required value="<?php echo e(\Carbon\Carbon::parse($from)->format('d/m/Y') ?? ''); ?>">
                </div>
            </div>
        </div>

        <div class="col-sm-6 col-md-3">
            <div class="form-group form-focus">
                <label class="focus-label">To</label>
                <div class="cal-icon">
                    <input class="form-control floating datetimepicker" type="text" name="to" required value="<?php echo e(\Carbon\Carbon::parse($to)->format('d/m/Y') ?? ''); ?>">
                </div>
            </div>
        </div>

        <div class="col-sm-6 col-md-3">
            <button type="submit" class="btn btn-success btn-block">Search</button>
        </div>
    </div>
</form>

<?php echo $__env->make('admin.report.komisi.table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<script>
    $('.report').DataTable({
        dom: 'Bfrtip',
        buttons: [{
                extend: 'copy',
                className: 'btn-default',
                exportOptions: {
                    columns: ':visible'
                }
            },
            {
                extend: 'excel',
                className: 'btn-default',
                title: 'Laporan Komisi <?php echo e($rl ? " Pegawai " . $rl : "Semua Pegawai"); ?>',
                messageTop: 'Tanggal <?php echo e($from); ?>  -  <?php echo e($to); ?>',
                footer: true,
                exportOptions: {
                    columns: ':visible'
                }
            },
            {
                extend: 'pdf',
                className: 'btn-default',
                title: 'Laporan Komisi <?php echo e($rl ? "Pegawai " . $rl : "Semua Pegawai"); ?>',
                messageTop: 'Tanggal <?php echo e($from); ?>  -  <?php echo e($to); ?>',
                footer: true,
                exportOptions: {
                    columns: ':visible'
                }
            },
        ]
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', ['title' =>'Report Komisi'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\yazfi\resources\views/admin/report/komisi/index.blade.php ENDPATH**/ ?>