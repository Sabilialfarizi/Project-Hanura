
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-sm-5 col-4">
        <h4 class="page-title">Penerimaan Barang</h4>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="card shadow" id="card">
            <div class="card-body">
                <div class="row custom-invoice">
                    <div class="col-sm-6 col-sg-4 m-b-4">
                        <div class="dashboard-logo">
                            <img src="<?php echo e(url('/img/logo/yazfi.png ')); ?>" alt="Image" />
                        </div>
                    </div>
                    <div class="col-sm-6 col-sg-4 m-b-4">
                        <div class="invoice-details">
                            <h3 class="text-uppercase"></h3>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-6 col-sg-4 m-b-4">
                        <h5>Invoice to:</h5>
                        <ul class="list-unstyled">
                            <li>
                                <h5><strong></strong></h5>
                            </li>
                            <li><span></span></li>
                        </ul>
                    </div>
                </div>
                <form action="" method="get">

                    <div class="row">
                        <div class="col-sm-6 col-sg-4 m-b-4">
                            <ul class="list-unstyled">
                                <li>
                                    <div class="form-group">
                                        <label for="no_po">No Purchasing Order <span style="color: red">*</span></label>

                                        
                                        <div class="input-group mb-3">
                                            <input type="text" id="invoice" name="invoice" data-dependent="barang_id"
                                                class="form-control dynamic_function">
                                            <button type="search" name="search" class="btn btn-primary"><i
                                                    class="fa fa-search" aria-hidden="true"></i></button>
                                        </div>

                                    </div>

                                </li>
                            </ul>
                        </div>

                    </div>
                </form>
               

                <?php $__currentLoopData = $purchase; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php if(request()->get('invoice') == $item->invoice && $item->status_barang == $item->status = 'pending' ): ?>
                <div class="row">
                    <div class="col-sm-6 col-sg-4 m-b-4">
                        <ul class="list-unstyled">
                            <li>
                                <div class="form-group">
                                    <label for="supplier">Supplier <span style="color: red">*</span></label>
                                    <input type="text" readonly class="form-control"
                                        value="<?php echo e($item->supplier->nama); ?>">
                                </div>
                            </li>
                        </ul>
                    </div>
                    <div class="col-sm-6 col-sg-4 m-b-4">
                        <ul class="list-unstyled">
                            <li>
                                <div class="form-group">
                                    <label for="project">Project <span style="color: red">*</span></label>
                                    <input type="text" value="<?php echo e($item->project->nama_project); ?> " class="form-control"
                                        readonly>
                                </div>
                            </li>
                        </ul>
                    </div>
                    <div class="col-sm-6 col-sg-4 m-b-4">
                        <ul class="list-unstyled">
                            <li>
                                <div class="form-group">
                                    <label for="lokasi">Lokasi <span style="color: red">*</span></label>
                                    <input type="text" value="<?php echo e($item->lokasi); ?>" class="form-control" readonly>
                                </div>
                            </li>
                        </ul>
                    </div>
                    <div class="col-sm-6 col-sg-4 m-b-4">
                        <ul class="list-unstyled">
                            <li>
                                <div class="form-group">
                                    <label for="tanggal">Tanggal <span style="color: red">*</span></label>
                                    <input type="text" value="<?php echo e($item->created_at); ?>" class="form-control" readonly>

                                </div>
                            </li>
                        </ul>
                    </div>

                </div>

                <form action="<?php echo e(route('purchasing.penerimaan-barang.store')); ?>" name="form1" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-sm-6 col-sg-4 m-b-4">
                            <ul class="list-unstyled">
                                <li>
                                    <div class="form-group">
                                        <label for="tanggal">No Purchase Order <span style="color: red">*</span></label>
                                        <input type="text" readonly id="no_po" name="no_po" class="form-control"
                                            value="<?php echo e($item ? $item->invoice : ''); ?>">
                                    </div>
                                </li>
                            </ul>
                        </div>
                        <div class="col-sm-6 col-sg-4 m-b-4">
                            <ul class="list-unstyled">
                                <li>
                                    <div class="form-group">
                                        <label for="tanggal">Di ajukan <span style="color: red">*</span></label>
                                        <input type="text" readonly class="form-control"
                                            value="<?php echo e($item ? $item->admin->name : ''); ?>">
                                    </div>
                                </li>
                            </ul>
                        </div>
                        <div class="col-sm-6 col-sg-4 m-b-4">
                            <ul class="list-unstyled">
                                <li>
                                    <div class="form-group">
                                        <input type="hidden" readonly name="id_user" id="id_user" class="form-control"
                                            value="<?php echo e(auth()->user()->id); ?>">
                                    </div>
                                </li>
                            </ul>
                        </div>
                        <br>
                        <div class="col-md-12">
                            <div class="row">
                                <div class="col-sm-6 col-sg-4 m-b-4">
                                    <ul class="list-unstyled">
                                        <li>
                                            <div class="form-group">
                                                <h4 class="page-title">Insert Penerimaan Barang</h4>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-6 col-sg-4 m-b-4">
                                    <ul class="list-unstyled">
                                        <li>
                                            <div class="form-group">
                                                <label for="tanggal">No Penerimaan Barang <span
                                                        style="color: red">*</span></label>
                                                <input type="text" id="no_penerimaan_barang" name="no_penerimaan_barang"
                                                    readonly class="form-control" value="<?php echo e($nourut); ?>">
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                                <div class="col-sm-6 col-sg-4 m-b-4">
                                    <ul class="list-unstyled">
                                        <li>
                                            <div class="form-group">
                                                <label for="tanggal_penerimaan">Tanggal Penerimaan Barang<span
                                                        style="color: red">*</span></label>
                                                <input type="datetime-local" id="tanggal_penerimaan"
                                                    name="tanggal_penerimaan" class="form-control" required="" value="">
                                                <?php $__errorArgs = ['tanggal_penerimaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <small class="text-danger"><?php echo e($message); ?></small>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                                <div class="col-sm-6 col-sg-4 m-b-4">
                                    <ul class="list-unstyled">
                                        <li>
                                            <div class="form-group">
                                                <label for="warehouses">Warehouse</label>
                                                <select name="id_warehouse" id="id_warehouse" class="form-control">
                                                    <option disabled selected>-- Select Warehouse --</option>
                                                    <?php $__currentLoopData = $warehouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $warehouse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($warehouse->id); ?>">
                                                        <?php echo e($warehouse->nama_warehouse); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>

                                                <?php $__errorArgs = ['id_warehouse'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <small class="text-danger"><?php echo e($message); ?></small>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </li>
                                    </ul>
                                </div>

                            </div>
                            <div class="table-responsive">
                                <table class="table table-bordered  report">
                                    <tr style="font-size:12px;" class="bg-success">
                                        <th class=" text-light">No.</th>
                                        <th class="text-light">Nama Barang</th>
                                        <th class="text-light">Qty Received</th>
                                        <th class="text-light">Qty Order</th>
                                        <th class="text-light">Harga Satuan</th>
                                        <th class="text-light"> Total</th>
                                        <th class="text-light"> Status Barang</th>
                                    </tr>
                                    <br>
                                    <br>
                                    <tbody id="dynamic_field">
                                        <script src="<?php echo e(asset('/')); ?>js/jquery-3.2.1.min.js"></script>
                                        <script src="<?php echo e(asset('/')); ?>js/select2.min.js"></script>

                                        <?php $__currentLoopData = $purchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="rowComponent">
                                            <td>
                                                <?php echo e($loop->iteration); ?>

                                            </td>
                                            <td>

                                                <input type="text" value="<?php echo e($purchase->barang->nama_barang); ?>"
                                                    class="form-control" disabled>
                                                <input type="hidden" name="barang_id[<?php echo e($loop->iteration); ?>]"
                                                    data="<?php echo e($loop->iteration); ?>" id="barang_id"
                                                    value="<?php echo e($purchase->barang_id); ?>"
                                                    class="form-control barang_id-<?php echo e($loop->iteration); ?>">

                                                <input type="hidden" name="id_purchase[<?php echo e($loop->iteration); ?>]"
                                                    data="<?php echo e($loop->iteration); ?>" id="id_purchase"
                                                    value="<?php echo e($purchase->id); ?>"
                                                    class="form-control id_purchase-<?php echo e($loop->iteration); ?>">

                                                <?php $__errorArgs = ['barang_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <small class="text-danger"><?php echo e($message); ?></small>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </td>
                                            <td>
                                                <input type="number" name="qty_received[<?php echo e($loop->iteration); ?>]"
                                                    class="form-control qty_received-<?php echo e($loop->iteration); ?>"
                                                    data="<?php echo e($loop->iteration); ?>"
                                                    onkeyup="testNum(this),hitung(this), HowAboutIt(this),qtyText(this)"
                                                    id="qty_received" placeholder=" 0">
                                            </td>

                                            <td>
                                                <input type="number" value="<?php echo e($purchase->qty); ?>"
                                                    data="<?php echo e($loop->iteration); ?>" name="qty[<?php echo e($loop->iteration); ?>]"
                                                    id="qty" class="form-control qty-<?php echo e($loop->iteration); ?>"
                                                    class="form-control" placeholder="0" required="" readonly>


                                                <?php $__errorArgs = ['qty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <small class="text-danger"><?php echo e($message); ?></small>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                <input type="hidden" data="<?php echo e($loop->iteration); ?>"
                                                    name="qty_partial[<?php echo e($loop->iteration); ?>]" id="qty_partial"
                                                    class="form-control qty_partial-<?php echo e($loop->iteration); ?>"
                                                    placeholder="0" readonly>

                                                <?php $__errorArgs = ['qty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <small class="text-danger"><?php echo e($message); ?></small>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                            </td>
                                            <td>
                                                <input type="number" value="<?php echo e($purchase->harga_beli); ?>"
                                                    name="harga_beli[<?php echo e($loop->iteration); ?>]"
                                                    class="form-control harga_beli-<?php echo e($loop->iteration); ?>"
                                                    data="<?php echo e($loop->iteration); ?>" placeholder="0" id="harga_beli"
                                                    required="" readonly>

                                                <?php $__errorArgs = ['harga_beli'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <small class="text-danger"><?php echo e($message); ?></small>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </td>
                                            <td>
                                                <input type="number" value="" name="total[<?php echo e($loop->iteration); ?>]"
                                                    readonly
                                                    class="form-control total-<?php echo e($loop->iteration); ?> total-form"
                                                    placeholder="0" required="">

                                                <?php $__errorArgs = ['total'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <small class="text-danger"><?php echo e($message); ?></small>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </td>
                                            <td>
                                                <input type="text" value="<?php echo e($purchase->status_barang); ?>"
                                                    name="status_barang[<?php echo e($loop->iteration); ?>]" id="status_barang"
                                                    class="form-control status_barang-<?php echo e($loop->iteration); ?> status-form"
                                                    readonly placeholder="Status Barang" required="">
                                                <?php $__errorArgs = ['status_barang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <small class="text-danger"><?php echo e($message); ?></small>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                            </td>


                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>

                                </table>

                                <div class="col-sm-4 offset-sm-8">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label>Total</label>
                                            <input type="text" id="sub_total" name="total" readonly class="form-control"
                                                value="">
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <label for="PPN">Include PPN</label>
                                        <div class="input-group">
                                            <input type="type" readonly id="PPN" value="<?php echo e($ppn ? $ppn->PPN : ''); ?>"
                                                name="ppn" onchange="HowAboutIt()" class="form-control"
                                                aria-label="Amount (to the nearest dollar)">
                                            <div class="input-group-append">
                                                <span class="input-group-text">%</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label>Grand Total</label>
                                            <input type="text" id="grandtotal" name="grandtotal" readonly
                                                class="form-control" value="">
                                        </div>
                                    </div>

                                    <div class="col-sm-1 offset-sm-8">
                                        <button type="submit" class="btn btn-primary" id="submit">Submit</button>
                                    </div>
                                </div>

                                <script>
                                    function hitung(e) {
                                        let attr = $(e).attr('data')
                                        // let qty = $(`.qty-${attr}`).val()
                                        let harga = $(`.harga_beli-${attr}`).val()
                                        let qty_received = $(`.qty_received-${attr}`).val()
                                        // console.log(qty_received);
                                        let total_qty = parseInt(qty_received * harga)
                                        // let total = parseInt(harga * qty) + total_qty
                                        $(`.total-${attr}`).val(total_qty)

                                    }

                                    function qtyText(e) {
                                        let attr = $(e).attr('data')
                                        let qty = $(`.qty-${attr}`).val()
                                        let qty_update = $(`.qty_received-${attr}`).val()

                                        let updated_qty = parseInt(qty - qty_update)
                                        $(`.qty_partial-${attr}`).val(updated_qty)


                                    }



                                    // function TotalAbout(e) {
                                    //     let sub_total = document.getElementById('sub_total')
                                    //     let total = 0;
                                    //     let coll = document.querySelectorAll('.total-form')
                                    //     for (let i = 0; i < coll.length; i++) {
                                    //         let ele = coll[i]
                                    //         total += parseInt(ele.value)
                                    //     }
                                    //     sub_total.value = total
                                    //     document.getElementById('grandtotal').value = total;
                                    // }

                                    function HowAboutIt(e) {
                                        let sub_total = document.getElementById('sub_total')
                                        let total = 0;
                                        let coll = document.querySelectorAll('.total-form')
                                        for (let i = 0; i < coll.length; i++) {
                                            let ele = coll[i]
                                            total += parseInt(ele.value)
                                        }
                                        sub_total.value = total
                                        let SUB = document.getElementById('sub_total').value;
                                        let PPN = document.getElementById('PPN').value;
                                        console.log(PPN);
                                        let tax = PPN / 100 * sub_total.value;
                                        console.log(tax);
                                        console.log(SUB);
                                        let grand_total = parseInt(SUB) + parseInt(tax);
                                        document.getElementById('grandtotal').value = grand_total;
                                        console.log(grand_total);
                                    }

                                </script>


                            </div>
                        </div>
                    </div>
                </form>
                <div class="row">
                    <div class="col-md-12">
                        <div class="table-responsive">

                            <div class="col-sm-5 col-4">
                                <h4 class="page-title">Riwayat Purchasing Order</h4>
                            </div>

                            <table class="table table-bordered  report">
                                <tr style="font-size:12px;" class="bg-success">
                                    <th class=" text-light">No.</th>
                                    <th class="text-light">Nama Barang</th>
                                    <th class="text-light">Qty</th>
                                    <th class="text-light">Harga</th>
                                    <th class="text-light"> Total</th>
                                    <th class="text-light"> Diajukan</th>
                                </tr>
                                <tbody id="dynamic_field">
                                    <?php $__currentLoopData = $purchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="rowComponent">
                                        <td>
                                            <?php echo e($loop->iteration); ?>

                                        </td>
                                        <td>
                                            <?php echo e($purchase->barang->nama_barang); ?>

                                        </td>
                                        <td>
                                            <?php echo e($purchase->qty); ?>

                                        </td>
                                        <td>
                                            Rp. <?php echo number_format($purchase->harga_beli, 0, ',', '.'); ?>
                                        </td>
                                        <td>
                                            Rp. <?php echo number_format($purchase->total, 0, ',', '.'); ?>
                                        </td>
                                        <td>
                                            <?php echo e($purchase->admin->name); ?>

                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <td colspan="3" rowspan="3"><b>Total Pembelian : </b></td>
                                        <td><b> PPN: </b></td>
                                        <td>
                                            <div class="input-group-append">
                                                <span class="input-group-text" style="background: white; border:0px;">
                                                    <?php echo e($ppn ? $ppn->PPN : ''); ?>%</span>
                                            </div>
                                        </td>

                                        <td></td>
                                    </tr>
                                    <tr>

                                        <td><b>Total: </b></td>

                                        <td>Rp. <?php echo number_format(\App\purchase::where('invoice',$purchase->invoice)->sum('total'), 0, ',', '.'); ?></td>

                                        <td></td>
                                    </tr>
                                    <tr>

                                        <td><b>Grand Total: </b></td>

                                        <td>Rp. <?php echo number_format($purchase->grand_total, 0, ',', '.'); ?></td>

                                        <td></td>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
                <?php if(request()->get('invoice') == $item->invoice && $item->status_barang == $item->status_barang =
                'partial'): ?>
                <div class="row">
                    <div class="col-sm-6 col-sg-4 m-b-4">
                        <ul class="list-unstyled">
                            <li>
                                <div class="form-group">
                                    <label for="supplier">Supplier <span style="color: red">*</span></label>
                                    <input type="text" readonly class="form-control"
                                        value="<?php echo e($item->supplier->nama); ?>">
                                </div>
                            </li>
                        </ul>
                    </div>
                    <div class="col-sm-6 col-sg-4 m-b-4">
                        <ul class="list-unstyled">
                            <li>
                                <div class="form-group">
                                    <label for="project">Project <span style="color: red">*</span></label>
                                    <input type="text" value="<?php echo e($item->project->nama_project); ?> " class="form-control"
                                        readonly>
                                </div>
                            </li>
                        </ul>
                    </div>
                    <div class="col-sm-6 col-sg-4 m-b-4">
                        <ul class="list-unstyled">
                            <li>
                                <div class="form-group">
                                    <label for="lokasi">Lokasi <span style="color: red">*</span></label>
                                    <input type="text" value="<?php echo e($item->lokasi); ?>" class="form-control" readonly>
                                </div>
                            </li>
                        </ul>
                    </div>
                    <div class="col-sm-6 col-sg-4 m-b-4">
                        <ul class="list-unstyled">
                            <li>
                                <div class="form-group">
                                    <label for="tanggal">Tanggal <span style="color: red">*</span></label>
                                    <input type="text" value="<?php echo e($item->created_at); ?>" class="form-control" readonly>

                                </div>
                            </li>
                        </ul>
                    </div>
                </div>

                <form action="<?php echo e(route('purchasing.penerimaan-barang.store')); ?>" name="form1" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-sm-6 col-sg-4 m-b-4">
                            <ul class="list-unstyled">
                                <li>
                                    <div class="form-group">
                                        <label for="tanggal">No Purchase Order <span style="color: red">*</span></label>
                                        <input type="text" readonly id="no_po" name="no_po" class="form-control"
                                            value="<?php echo e($item ? $item->invoice : ''); ?>">
                                    </div>
                                </li>
                            </ul>
                        </div>
                        <div class="col-sm-6 col-sg-4 m-b-4">
                            <ul class="list-unstyled">
                                <li>
                                    <div class="form-group">
                                        <label for="tanggal">Di ajukan <span style="color: red">*</span></label>
                                        <input type="text" readonly class="form-control"
                                            value="<?php echo e($item ? $item->admin->name : ''); ?>">
                                    </div>
                                </li>
                            </ul>
                        </div>
                        <div class="col-sm-6 col-sg-4 m-b-4">
                            <ul class="list-unstyled">
                                <li>
                                    <div class="form-group">
                                        <input type="hidden" readonly name="id_user" id="id_user" class="form-control"
                                            value="<?php echo e(auth()->user()->id); ?>">
                                    </div>
                                </li>
                            </ul>
                        </div>
                        <br>
                        <div class="col-md-12">
                            <div class="row">
                                <div class="col-sm-6 col-sg-4 m-b-4">
                                    <ul class="list-unstyled">
                                        <li>
                                            <div class="form-group">
                                                <h4 class="page-title">Insert Penerimaan Barang</h4>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-6 col-sg-4 m-b-4">
                                    <ul class="list-unstyled">
                                        <li>
                                            <div class="form-group">
                                                <label for="tanggal">No Penerimaan Barang <span
                                                        style="color: red">*</span></label>
                                                <input type="text" id="no_penerimaan_barang" name="no_penerimaan_barang"
                                                    readonly class="form-control" value="<?php echo e($nourut); ?>">
                                            </div>
                                        </li>
                                    </ul>
                                </div>

                                <div class="col-sm-6 col-sg-4 m-b-4">
                                    <ul class="list-unstyled">
                                        <li>
                                            <div class="form-group">
                                                <label for="tanggal_penerimaan">Tanggal Penerimaan Barang<span
                                                        style="color: red">*</span></label>
                                                <input type="datetime-local" id="tanggal_penerimaan"
                                                    name="tanggal_penerimaan" class="form-control" required="" value="">
                                                <?php $__errorArgs = ['tanggal_penerimaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <small class="text-danger"><?php echo e($message); ?></small>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                                <div class="col-sm-6 col-sg-4 m-b-4">
                                    <ul class="list-unstyled">
                                        <li>
                                            <div class="form-group">
                                                <label for="warehouse">Warehouse <span
                                                        style="color: red">*</span></label>
                                                <input type="text" readonly name="id_warehouse"class="form-control"
                                                    value="<?php echo e($gudang->purchase->warehouse->nama_warehouse); ?>">
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="table-responsive">
                                <table class="table table-bordered  report">
                                    <tr style="font-size:12px;" class="bg-success">
                                        <th class=" text-light">No.</th>
                                        <th class="text-light">Nama Barang</th>
                                        <th class="text-light">Qty Received</th>
                                        <th class="text-light">Qty Partial</th>
                                        <th class="text-light">Harga Satuan</th>
                                        <th class="text-light"> Total</th>
                                        <th class="text-light"> Status Barang</th>
                                    </tr>
                                    <br>
                                    <br>
                                    <tbody id="dynamic_field">
                                        <script src="<?php echo e(asset('/')); ?>js/jquery-3.2.1.min.js"></script>
                                        <script src="<?php echo e(asset('/')); ?>js/select2.min.js"></script>

                                        <?php $__currentLoopData = $penerimaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="rowComponent">
                                            <td>
                                                <?php echo e($loop->iteration); ?>

                                            </td>
                                            <td>

                                                <input type="text" value="<?php echo e($purchase->nama_barang); ?>"
                                                    class="form-control" disabled>
                                                <input type="hidden" name="barang_id[<?php echo e($loop->iteration); ?>]"
                                                    data="<?php echo e($loop->iteration); ?>" id="barang_id"
                                                    value="<?php echo e($purchase->barang_id); ?>"
                                                    class="form-control barang_id-<?php echo e($loop->iteration); ?>">
                                                <input type="hidden" name="id_purchase[<?php echo e($loop->iteration); ?>]"
                                                    data="<?php echo e($loop->iteration); ?>" id="id_purchase"
                                                    value="<?php echo e($purchase->id); ?>"
                                                    class="form-control id_purchase-<?php echo e($loop->iteration); ?>">


                                                <?php $__errorArgs = ['barang_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <small class="text-danger"><?php echo e($message); ?></small>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </td>
                                            <td>
                                                <input type="number" name="qty_received[<?php echo e($loop->iteration); ?>]"
                                                    class="form-control qty_received-<?php echo e($loop->iteration); ?>"
                                                    data="<?php echo e($loop->iteration); ?>"
                                                    onkeyup="testNum(this),hitung(this), HowAboutIt(this),qtyText(this)"
                                                    id="qty_received" placeholder=" 0">
                                            </td>

                                            <td>

                                                <input type="number" value="<?php echo e($purchase->qty_partial); ?>"
                                                    data="<?php echo e($loop->iteration); ?>" name="qty[<?php echo e($loop->iteration); ?>]"
                                                    id="qty" class="form-control qty-<?php echo e($loop->iteration); ?>"
                                                    class="form-control" placeholder="0" required="" readonly>

                                                <input type="hidden" data="<?php echo e($loop->iteration); ?>"
                                                    name="qty_partial[<?php echo e($loop->iteration); ?>]" id="qty_partial"
                                                    class="form-control qty_partial-<?php echo e($loop->iteration); ?>"
                                                    placeholder="0" value="<?php echo e($purchase->qty_partial); ?>" readonly>

                                                <?php $__errorArgs = ['qty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <small class="text-danger"><?php echo e($message); ?></small>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                            </td>


                                            <td>
                                                <input type="number" value="<?php echo e($purchase->harga_beli); ?>"
                                                    name="harga_beli[<?php echo e($loop->iteration); ?>]"
                                                    class="form-control harga_beli-<?php echo e($loop->iteration); ?>"
                                                    data="<?php echo e($loop->iteration); ?>" placeholder="0" id="harga_beli"
                                                    required="" readonly>

                                                <?php $__errorArgs = ['harga_beli'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <small class="text-danger"><?php echo e($message); ?></small>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </td>
                                            <td>
                                                <input type="number" value="" name="total[<?php echo e($loop->iteration); ?>]"
                                                    readonly
                                                    class="form-control total-<?php echo e($loop->iteration); ?> total-form"
                                                    placeholder="0" required="">

                                                <?php $__errorArgs = ['total'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <small class="text-danger"><?php echo e($message); ?></small>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </td>
                                            <td>
                                                <input type="text" value="<?php echo e($purchase->status_barang); ?>"
                                                    name="status_barang[<?php echo e($loop->iteration); ?>]" id="status_barang"
                                                    class="form-control status_barang-<?php echo e($loop->iteration); ?> status-form"
                                                    readonly placeholder="Status Barang" required="">
                                                <?php $__errorArgs = ['status_barang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <small class="text-danger"><?php echo e($message); ?></small>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                            </td>


                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>

                                </table>

                                <div class="col-sm-4 offset-sm-8">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label>Total</label>
                                            <input type="text" id="sub_total" name="total" readonly class="form-control"
                                                value="">
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <label for="PPN">Include PPN</label>
                                        <div class="input-group">
                                            <input type="type" readonly id="PPN"
                                                value="<?php echo e($ppn_partial ? $ppn_partial->PPN : ''); ?>" name="ppn"
                                                onchange="HowAboutIt()" class="form-control"
                                                aria-label="Amount (to the nearest dollar)">
                                            <div class="input-group-append">
                                                <span class="input-group-text">%</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label>Grand Total</label>
                                            <input type="text" id="grandtotal" name="grandtotal" readonly
                                                class="form-control" value="">
                                        </div>
                                    </div>

                                    <div class="col-sm-1 offset-sm-8">
                                        <button type="submit" class="btn btn-primary" id="submit">Submit</button>
                                    </div>
                                </div>

                                <script>
                                    function hitung(e) {
                                        let attr = $(e).attr('data')
                                        // let qty = $(`.qty-${attr}`).val()
                                        let harga = $(`.harga_beli-${attr}`).val()
                                        let qty_received = $(`.qty_received-${attr}`).val()
                                        // console.log(qty_received);
                                        let total_qty = parseInt(qty_received * harga)
                                        // let total = parseInt(harga * qty) + total_qty
                                        $(`.total-${attr}`).val(total_qty)

                                    }

                                    function qtyText(e) {
                                        let attr = $(e).attr('data')
                                        let qty = $(`.qty-${attr}`).val()
                                        let qty_update = $(`.qty_received-${attr}`).val()

                                        let updated_qty = parseInt(qty - qty_update)
                                        $(`.qty_partial-${attr}`).val(updated_qty)


                                    }



                                    // function TotalAbout(e) {
                                    //     let sub_total = document.getElementById('sub_total')
                                    //     let total = 0;
                                    //     let coll = document.querySelectorAll('.total-form')
                                    //     for (let i = 0; i < coll.length; i++) {
                                    //         let ele = coll[i]
                                    //         total += parseInt(ele.value)
                                    //     }
                                    //     sub_total.value = total
                                    //     document.getElementById('grandtotal').value = total;
                                    // }

                                    function HowAboutIt(e) {
                                        let sub_total = document.getElementById('sub_total')
                                        let total = 0;
                                        let coll = document.querySelectorAll('.total-form')
                                        for (let i = 0; i < coll.length; i++) {
                                            let ele = coll[i]
                                            total += parseInt(ele.value)
                                        }
                                        sub_total.value = total
                                        let SUB = document.getElementById('sub_total').value;
                                        let PPN = document.getElementById('PPN').value;
                                        console.log(PPN);
                                        let tax = PPN / 100 * sub_total.value;
                                        console.log(tax);
                                        console.log(SUB);
                                        let grand_total = parseInt(SUB) + parseInt(tax);
                                        document.getElementById('grandtotal').value = grand_total;
                                        console.log(grand_total);
                                    }

                                </script>


                            </div>
                        </div>
                    </div>
                </form>
                <div class="row">
                    <div class="col-md-12">
                        <div class="table-responsive">

                            <div class="col-sm-5 col-4">
                                <h4 class="page-title">Riwayat Purchasing Order</h4>
                            </div>

                            <table class="table table-bordered  report">
                                <tr style="font-size:12px;" class="bg-success">
                                    <th class=" text-light">No.</th>
                                    <th class="text-light">Nama Barang</th>
                                    <th class="text-light">Qty</th>
                                    <th class="text-light">Harga</th>
                                    <th class="text-light"> Total</th>
                                    <th class="text-light"> Diajukan</th>
                                </tr>
                                <tbody id="dynamic_field">
                                    <?php $__currentLoopData = $penerimaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="rowComponent">
                                        <td>
                                            <?php echo e($loop->iteration); ?>

                                        </td>
                                        <td>
                                            <?php echo e($purchase->nama_barang); ?>

                                        </td>
                                        <td>
                                            <?php echo e($purchase->qty_partial); ?>

                                        </td>
                                        <td>
                                            Rp. <?php echo number_format($purchase->harga_beli, 0, ',', '.'); ?>
                                        </td>
                                        <td>
                                            Rp. <?php echo number_format($purchase->harga_beli * $purchase->qty_partial, 0, ',', '.'); ?>
                                        </td>
                                        <td>
                                            <?php echo e($purchase->name); ?>

                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                <tfoot>
                                    <?php $__currentLoopData = $penerimaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td colspan="3" rowspan="3"><b>Total Pembelian : </b></td>
                                        <td><b>Total: </b></td>

                                        
                                        <td>
                                            Rp. <?php echo number_format($purchase->harga_beli * $purchase->qty_partial, 0, ',', '.'); ?>
                                        </td>


                                        <td></td>
                                    </tr>
                                    <tr>



                                        <td><b> PPN: </b></td>

                                        <td>
                                            <div class="input-group-append">
                                                <span class="input-group-text" style="background: white; border:0px;">
                                                    <?php echo e($ppn_partial ? $ppn_partial->PPN : ''); ?>%</span>
                                            </div>
                                        </td>

                                        <td></td>
                                    </tr>
                                    <tr>

                                        <td><b>Grand Total: </b></td>

                                        <td>
                                            Rp. <?php echo number_format($purchase->harga_beli * $purchase->qty_partial / 100 *
                                            $ppn_partial->PPN + $purchase->harga_beli * $purchase->qty_partial, 0, ',', '.'); ?>
                                        </td>

                                        <td></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
                <?php if(request()->get('invoice') == $item->invoice && $item->status_barang == $item->status = 'completed'): ?>
                <div class="row">
                    <div class="col-sm-6 col-sg-4 m-b-4">
                        <div class="alert alert-success alert-dismissible" role="alert">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span
                                    aria-hidden="true">&times;</span></button>
                            Data Sudah Completed
                        </div>
                    </div>

                </div>

                <?php endif; ?>
                

               

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>


</html>
<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
<script>
    var formatter = function (num) {
        var str = num.toString().replace("", ""),
            parts = false,
            output = [],
            i = 13,
            formatted = null;
        if (str.indexOf(".") > 0) {
            parts = str.split(".");
            str = parts[0];
        }
        str = str.split("").reverse();
        for (var j = 0, len = str.length; j < len; j++) {
            if (str[j] != ",") {
                output.push(str[j]);
                if (i % 3 == 0 && j < (len - 1)) {
                    output.push(",");
                }
                i++;
            }
        }
        formatted = output.reverse().join("");
        return ("" + formatted + ((parts) ? "." + parts[1].substr(0, 2) : ""));
    };


    // document.getElementById('submit').disabled = true

    function form_dinamic() {
        let index = $('#dynamic_field tr').length + 1
        document.getElementById('counter').innerHTML = index
        // let template = `
        // <tr class="rowComponent">
        //             <td hidden>
        //                 <input type="hidden" name="barang_id[${index}]" class="barang_id-${index}">
        //             </td>
        //             <td>
        //                 <select required name="barang_id[${index}]" id="${index}" class="form-control select-${index}"></select>
        //             </td>
        //             <td>
        //                 <input type="number" name="qty[${index}]"  class="form-control qty-${index}" placeholder="0">
        //             </td>
        //             <td>
        //                 <input type="number" name="harga_beli[${index}]" class="form-control harga_beli-${index} waktu" placeholder="0"  data="${index}" onkeyup="hitung(this)">
        //             </td>
        //             <td>
        //                 <input type="number" name="total[${index}]" disabled class="form-control total-${index} total-form"  placeholder="0">
        //             </td>
        //             <td>
        //                 <button type="button" class="btn btn-danger btn-sm" onclick="remove(this)">Delete</button>
        //             </td>
        //         </tr>
        // `
        $('#dynamic_field').append(template)

        $(`.select-${index}`).select2({
            placeholder: 'Select Product',
            ajax: {
                url: `/admin/where/product`,
                processResults: function (data) {
                    console.log(data)
                    return {
                        results: data
                    };
                },
                cache: true
            }
        });


    }

    function submit_form() {
        document.form1.submit();
        document.form2.submit();
    }

    function remove(q) {
        $(q).parent().parent().remove()
    }
    $('.remove').on('click', function () {
        $(this).parent().parent().remove()
    })


    $(document).ready(function () {
        $('#add').on('click', function () {
            form_dinamic()
        })
    })
    $(document).ready(function () {
        $('.dynamic_function').change(function () {
            var invoice = $(this).val();
            var id = $(this).val();
            var div = $(this).parent();
            var op = " ";
            console.log(invoice);
            $.ajax({
                url: `/purchasing/where/penerimaan/search`,
                method: "get",
                data: {
                    'invoice': invoice,
                },
                success: function (data) {
                    console.log(data);
                    for (var i = 0; i < data.length; i++) {
                        var id = data[i].id;
                        // console.log(supplier_id);
                        document.getElementById('id').value = id;

                        // var supplier_id = data[i].supplier_id;
                        // // console.log(supplier_id);
                        // document.getElementById('supplier_id').value = supplier_id;
                        // document.getElementById('supplier_id').defaultvalue = supplier_id;

                        // var project_id = data[i].project_id;
                        // // console.log(project_id);
                        // document.getElementById('project_id').value = project_id;
                        // document.getElementById('project_id').defaultvalue = project_id;

                        // var lokasi = data[i].lokasi;
                        // // console.log(lokasi);
                        // document.getElementById('lokasi').value = lokasi;
                        // document.getElementById('lokasi').defaultvalue = lokasi;

                        // var created_at = data[i].created_at;
                        // // console.log(created_at);
                        // document.getElementById('created_at').value = created_at;
                        // document.getElementById('created_at').defaultvalue = created_at;


                    };
                },
                error: function () {}
            })
        })
    })

    function testNum(e) {
        let result = 0;
        let attr = $(e).attr('data')
        let qty_received = $(`.qty_received-${attr}`).val()
        // console.log(qty_received)
        let qty = $(`.qty-${attr}`).val()
        // console.log(qty)


        if (qty != qty_received) {
            result = 'partial';
        } else {
            result = 'completed';

        }

        $(`.status_barang-${attr}`).val(result)


    }

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', ['title' => 'Create Penerimaan Barang'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\yazfi\resources\views/purchasing/penerimaan-barang/create.blade.php ENDPATH**/ ?>