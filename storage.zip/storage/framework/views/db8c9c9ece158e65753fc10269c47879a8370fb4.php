
<?php $__env->startSection('content'); ?>
<div class="row justify-content-center text-center">
    <div class="col-sm-4 col-3">
        <h4 class="page-title">Add Rincian Gaji</h4>
    </div>
</div>
<div class="row justify-content-center">
    <div class="col-sm-6">
        <form action="<?php echo e(route('hrd.rincianpenggajian.store')); ?>" method="post" id="form">
            <?php echo csrf_field(); ?>
            <?php echo $__env->make('hrd.rincianpenggajian.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', ['title' => 'Create Rincian Gaji'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\yazfi\resources\views/hrd/rincianpenggajian/create.blade.php ENDPATH**/ ?>