<div class="row">
    <div class="col-md-12">
        <div class="table-responsive">
            <table class="table table-striped table-bordered custom-table report">
                <thead>
                    <tr>
                        <th class="text-center">No</th>
                        <th>Nama Pasien</th>
                        <th>Cabang</th>
                        <th>No Appointment</th>
                        <th>Amount</th>
                        <th>Paid</th>
                        <th>Unpaid</th>
                    </tr>
                </thead>
                <?php
                $amount = 0;
                $paid = 0;
                $unpaid = 0;
                ?>
                <tbody>
                    <?php $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="text-center"><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($appointment->pasien->nama); ?></td>
                        <td><?php echo e($appointment->cabang->nama); ?></td>
                        <td><?php echo e($appointment->no_booking); ?></td>
                        <?php
                        $pajak = $appointment->tindakan->sum('nominal') * $appointment->cabang->ppn / 100
                        ?>
                        <td>Rp. <?php echo number_format($appointment->tindakan->sum('nominal') + $pajak, 0, ',', '.'); ?> </td>
                        <td>Rp. <?php echo number_format($appointment->rincian->sum('dibayar'), 0, ',', '.'); ?> </td>
                        <td>Rp. <?php echo number_format($appointment->tindakan->sum('nominal') + $pajak - $appointment->rincian->sum('dibayar'), 0, ',', '.'); ?> </td>
                    </tr>
                    <?php
                    $amount += $appointment->tindakan->sum('nominal') + $pajak;
                    $paid += $appointment->rincian->sum('dibayar');
                    $unpaid += $appointment->tindakan->sum('nominal') + $pajak - $appointment->rincian->sum('dibayar');
                    ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>

                <tfoot>
                    <tr>
                        <td class="text-center"><b>Grand Total</b></td>
                        <td colspan="3"></td>
                        <td>Rp. <?php echo number_format($amount, 0, ',', '.'); ?></td>
                        <td>Rp. <?php echo number_format($paid, 0, ',', '.'); ?></td>
                        <td>Rp. <?php echo number_format($unpaid, 0, ',', '.'); ?></td>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\yazfi\resources\views/admin/report/appoinment/table.blade.php ENDPATH**/ ?>