<div class="row">
    <div class="col-md-12">
        <div class="table-responsive">
            <table class="table table-striped table-bordered custom-table report">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Tanggal</th>
                        <th>No Booking</th>
                        <th>Nama</th>
                        <th>Persentase</th>
                        <!-- <th>Role</th> -->
                        <th>Nominal</th>
                        <th>Kasir</th>
                    </tr>
                </thead>
                <?php
                $total = 0;
                ?>
                <?php if($komisi != null): ?>
                <tbody>
                    <?php $__currentLoopData = $komisi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kms): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($kms->booking->created_at); ?></td>
                        <td><?php echo e($kms->booking->no_booking); ?></td>
                        <td><?php echo e($kms->user->name); ?></td>
                        <td>
                            <?php $__currentLoopData = $kms->user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                            $persentase = \App\Komisi::where('role_id',$rl->id)->first();
                            ?>
                            <?php echo e($persentase->persentase); ?> %
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                        <!-- <td>
                            <?php $__currentLoopData = $kms->user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($rl->key); ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td> -->
                        <td>Rp. <?php echo number_format($kms->nominal_komisi, 0, ',', '.'); ?></td>
                        <?php
                        $kasir = \App\User::find($kms->booking->resepsionis_id)
                        ?>
                        <td><?php echo e($kasir->name); ?></td>
                    </tr>
                    <?php
                    $total += $kms->nominal_komisi;
                    ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot>
                    <tr>
                        <td><strong>Grand Total</strong></td>
                        <td></td>
                        <td></td>
                        <!-- <td></td> -->
                        <td></td>
                        <td></td>
                        <td>Rp. <?php echo number_format($total, 0, ',', '.'); ?></td>
                        <td></td>
                    </tr>
                </tfoot>
                <?php endif; ?>

            </table>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\yazfi\resources\views/admin/report/komisi/table.blade.php ENDPATH**/ ?>