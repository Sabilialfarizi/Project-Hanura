
<?php $__env->startSection('content'); ?>
<div class="row justify-content-center text-center">
    <div class="col-sm-4 col-3">
        <h4 class="page-title">Edit Jam Masuk dan Pulang</h4>
    </div>
</div>

<div class="row justify-content-center">
    <div class="col-sm-6">
        <form action="<?php echo e(route('hrd.jam.update', $jam->id)); ?>" method="post" id="form">
            <?php echo csrf_field(); ?>
            <?php echo method_field('put'); ?>
            <?php echo $__env->make('hrd.jam.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', ['title' => 'Edit Jam Masuk dan Pulang'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\yazfi\resources\views/hrd/jam/edit.blade.php ENDPATH**/ ?>