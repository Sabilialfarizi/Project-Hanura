<ul>
    <li class="menu-title">Main</li>
    <li class="<?php echo e(request()->is('dashboard*') ? 'active' : ''); ?>">
        <a href="/dashboard"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a>
    </li>

    <li class="submenu">
        <a href="#"><i class="fa fa-users"></i> <span> Master</span> <span class="menu-arrow"></span></a>
        <ul style="display: none;">
            <li class="<?php echo e(request()->is('hrd/users*') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('hrd.users.index')); ?>"><span>User</span></a>
            </li>
            <li class="<?php echo e(request()->is('hrd/permission*') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('hrd.permission.index')); ?>">
                    <span>Roles</span></a></li>
            <li class="<?php echo e(request()->is('hrd/jabatan*') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('hrd.jabatan.index')); ?>"><span>Jabatan</span></a>
            </li>
            <li class="<?php echo e(request()->is('hrd/roles*') ? 'active' : ''); ?>"> <a href="<?php echo e(route('hrd.roles.index')); ?>">
                    <span>Divisi</span></a></li>
            
</ul>
</li>
<li class="submenu">
    <a href="#"><i class="fa-solid fa-hand-holding-dollar"></i> <span>Reinburst</span> <span
            class="menu-arrow"></span></a>
    <ul style="display: none;">
        <li class="<?php echo e(request()->is('hrd/reinburst*') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('hrd.reinburst.index')); ?>"> <span>Rekap Reinburst</span></a>
        </li>
        <li class="<?php echo e(request()->is('hrd/penerimaan*') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('hrd.penerimaan.index')); ?>"><span>Acc Reinburst</span></a>
        </li>
    </ul>
</li>

<li class="<?php echo e(request()->is('hrd/sales*') ? 'active' : ''); ?>">
    <a href="<?php echo e(route('hrd.sales.index')); ?>"><i class="fa fa-user-plus" aria-hidden="true"></i> <span>Team
            Sales</span></a>
</li>

<li class="<?php echo e(request()->is('hrd/pengajuan*') ? 'active' : ''); ?>">
    <a href="<?php echo e(route('hrd.pengajuan.index')); ?>"><i class="fa-solid fa-file-invoice"></i><span>Pengajuan dana</span></a>
</li>
<li class="submenu">
    <a href="#"><i class="fa-solid fa-calendar-check"></i> <span>Attandance</span><span class="menu-arrow"></span></a>
    <ul style="display: none;">
        <li class="<?php echo e(request()->is('hrd/attendance*') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('hrd.attendance.index')); ?>"><span>Absen</span></a>
        </li>
        <li class="<?php echo e(request()->is('hrd/MstLokasi*') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('hrd.MstLokasi.index')); ?>">
                <span>Lokasi</span></a></li>
        <li class="<?php echo e(request()->is('hrd/jam*') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('hrd.jam.index')); ?>">
                <span>Jam Masuk Dan Pulang</span></a></li>
    </ul>
</li>

<li class="submenu">
    <a href="#"><i class="fa fa-money" aria-hidden="true"></i> <span>Payroll</span><span class="menu-arrow"></span></a>
    <ul style="display: none;">
        <li class="<?php echo e(request()->is('hrd/penerimaangaji*') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('hrd.penerimaangaji.index')); ?>"><span>Penerimaan</span></a>
        </li>
        <li class="<?php echo e(request()->is('hrd/potongan*') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('hrd.potongan.index')); ?>">
                <span>Potongan</span></a></li>
        <li class="<?php echo e(request()->is('hrd/rincianpenggajian*') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('hrd.rincianpenggajian.index')); ?>">
                <span>Rincian Gaji</span></a></li>
        <li class="<?php echo e(request()->is('hrd/gaji*') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('hrd.gaji.index')); ?>"><span>Pengajian</span></a>
        </li>
</li>
</ul>
<?php /**PATH C:\xampp\htdocs\yazfi\resources\views/components/hrd/sidebar.blade.php ENDPATH**/ ?>