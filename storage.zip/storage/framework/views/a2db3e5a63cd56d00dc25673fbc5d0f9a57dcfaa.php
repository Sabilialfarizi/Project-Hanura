

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center text-center">
    <div class="col-md-6">
        <h4 class="page-title">Edit Team Sales</h4>
    </div>
</div>

<form action="<?php echo e(route('hrd.tim-sales.update', $user->id)); ?>" method="post" enctype="multipart/form-data">
    <?php echo method_field('PATCH'); ?>
    <?php echo csrf_field(); ?>
    <?php echo $__env->make('hrd.tim-sales.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<script>
    $(".select2").select2()
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', ['title' => 'Edit Team Sales'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\yazfi\resources\views/hrd/tim-sales/edit.blade.php ENDPATH**/ ?>