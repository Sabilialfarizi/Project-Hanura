<ul>
    <li class="menu-title">Main</li>
    <li class="<?php echo e(request()->is('dashboard*') ? 'active' : ''); ?>">
        <a href="/dashboard"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a>
    </li>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product-access')): ?>
    <li class="<?php echo e(request()->is('admin/pembatalans*') ? 'active' : ''); ?>">
        <a href="<?php echo e(route('admin.pembatalans.index')); ?>"><i class="fa fa-building"></i> <span>Canceling</span></a>
    </li>
    <?php endif; ?>
    <?php if(auth()->check() && auth()->user()->hasRole('super-admin')): ?>
    <li class="submenu">
        <a href="#" class=""><i class="fa fa-cog"></i> <span> Master </span> <span class="menu-arrow"></span></a>
        <ul style="display: none;">
            <li class="submenu">
                <a href="#" class=""><i class="fa fa-shopping-bag"></i> <span> Master Barang </span> <span class="menu-arrow"></span></a>
                <ul style="display: none;">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product-access')): ?>
                    <li class="<?php echo e(request()->is('admin/product*') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('admin.product.index')); ?>"><span>Barang</span></a>
                    </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product-access')): ?>
                    <li class="<?php echo e(request()->is('admin/kategori*') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('admin.kategori.index')); ?>"><span>Kategori Barang</span></a>
                    </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product-access')): ?>
                    <li class="<?php echo e(request()->is('admin/satuan*') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('admin.satuan.index')); ?>"><span>Satuan Barang</span></a>
                    </li>
                    <?php endif; ?>

                </ul>
            </li>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product-access')): ?>
            <li class="<?php echo e(request()->is('admin/unit*') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('admin.unit.index')); ?>"><i class="fa fa-building"></i> <span>Unit Rumah</span></a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('supplier-access')): ?>
            <li class="<?php echo e(request()->is('admin/supplier*') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('admin.supplier.index')); ?>"><i class="fa fa-user-o"></i> <span>Vendor</span></a>
            </li>
            <?php endif; ?>
            
          
            
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product-access')): ?>
            <li class="<?php echo e(request()->is('admin/warehouse*') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('admin.warehouse.index')); ?>"><i class="fa fa-archive"></i> <span>Warehouse</span></a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product-access')): ?>
            <li class="<?php echo e(request()->is('admin/reinburst*') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('admin.reinburst.index')); ?>"><i class="fa-solid fa-hand-holding-dollar"></i> <span>Reinburst</span></a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product-access')): ?>
            <li class="<?php echo e(request()->is('admin/customer*') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('admin.customer.index')); ?>"><i class="fa fa-user-o"></i> <span>Customer</span></a>
            </li>
            <?php endif; ?>
         
        </ul>
    </li>
    <?php endif; ?>
   
</ul><?php /**PATH C:\xampp\htdocs\yazfi\resources\views/components/admin/sidebar.blade.php ENDPATH**/ ?>