

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-6">
        <h1 class="page-title">Show Divisi</h1>
        <div class="card">
            <div class="card-header">
                <h5 class="text-bold card-title">Show Divisi</h5>
            </div>

            <div class="card-body">
                <div class="mb-3">
                    <h5>Name : </h5>
                    <span class="custom-badge status-green"><?php echo e($role->name); ?></span>
                </div>
                <div class="">
                    <h5>Permissions : </h5>
                    <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span class="badge badge-primary"><?php echo e($permission->name); ?></span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', ['title' => 'Roles'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\yazfi\resources\views/hrd/roles/show.blade.php ENDPATH**/ ?>