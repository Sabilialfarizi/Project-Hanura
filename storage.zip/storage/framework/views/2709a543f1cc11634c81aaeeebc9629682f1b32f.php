

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center text-center">
    <div class="col-sm-4 col-3">
        <h4 class="page-title">Edit Produk</h4>
    </div>
</div>

<div class="row justify-content-center">
    <div class="col-sm-6">
        <form action="<?php echo e(route('admin.kategori.update', $kategori->id)); ?>" method="post">
            <?php echo method_field('PATCH'); ?>
            <?php echo csrf_field(); ?>

            <div class="col-sm-6 col-sg-4 m-b-4">
                <div class="form-group">
                    <label for="nama_kategori">Nama Kategori</label>
                    <input type="text" required="" name="nama_kategori" id="nama_kategori" class="form-control"
                        value="<?php echo e($kategori->nama_kategori ?? ''); ?>">
            
                    <?php $__errorArgs = ['nama_kategori'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="col-sm-6 col-sg-4 m-b-4">
                <div class="form-group">
                    <label for="created_at">Tanggal</label>
                    <input type="datetime-local" name="created_at" id="created_at" class="form-control"
                        value="<?php echo e(Carbon\Carbon::parse($kategori->created_at)->format('Y-m-d').'T'.Carbon\Carbon::parse($kategori->created_at)->format('H:i:s')); ?>">
            
                    <?php $__errorArgs = ['created_at'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            
            <div class="col-sm-6 col-sg-4 m-b-4 text-left">
                <button type="submit" class="btn btn-primary submit-btn"><i class="fa fa-save"></i> Save</button>
            </div>
            

        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', ['title' => 'Product'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\yazfi\resources\views/admin/kategoribarang/edit.blade.php ENDPATH**/ ?>