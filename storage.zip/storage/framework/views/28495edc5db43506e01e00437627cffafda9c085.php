

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-4">
        <h1 class="page-title">Master Jabatan</h1>
    </div>

    <div class="col-sm-8 text-right m-b-20">

        <a href="<?php echo e(route('hrd.jabatan.create')); ?>" class="btn btn btn-primary btn-rounded float-right"><i class="fa fa-plus"></i> Add Jabatan</a>

    </div>
</div>

 <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.alert','data' => []]); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 


<div class="row">
    <div class="col-sm-12">
        <div class="table-responsive">
            <table class="table table-bordered table-striped custom-table report">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama</th>
                        <th>Perusahaan</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__currentLoopData = $jabatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jabatans): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($jabatans->nama); ?></td>
                        <td><?php echo e($jabatans->perusahaan->nama_perusahaan); ?></td>
                        <td><?php echo e($jabatans->status); ?></td>
                        <td>

                            <a href="<?php echo e(route('hrd.jabatan.edit', $jabatans->id)); ?>" class="btn btn-sm btn-info"><i class="fa fa-edit"></i></a>
                            <form action="<?php echo e(route('hrd.jabatan.destroy', $jabatans->id)); ?>" method="post" style="display: inline;" class="delete-form">
                                <?php echo method_field('DELETE'); ?>
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-sm btn-danger"><i class="fa fa-trash"></i></button>
                            </form>

                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<script>
    $('.report').DataTable({
        dom: 'Bfrtip',
        buttons: [{
                extend: 'copy',
                className: 'btn-default',
                exportOptions: {
                    columns: ':visible'
                }
            },
            {
                extend: 'excel',
                className: 'btn-default',
                title: 'Laporan Jabatan ',
                messageTop: 'Tanggal  <?php echo e(request("from")); ?> - <?php echo e(request("to")); ?>',
                footer: true,
                exportOptions: {
                    columns: ':visible'
                }
            },
            {
                extend: 'pdf',
                className: 'btn-default',
                title: 'Laporan Jabatan ',
                messageTop: 'Tanggal <?php echo e(request("from")); ?> - <?php echo e(request("to")); ?>',
                footer: true,
                exportOptions: {
                    columns: ':visible'
                }
            },
        ]
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', ['title' => 'Master Jabatan'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\yazfi\resources\views/hrd/jabatan/index.blade.php ENDPATH**/ ?>