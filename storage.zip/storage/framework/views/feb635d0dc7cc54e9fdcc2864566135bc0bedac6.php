

<?php $__env->startSection('content'); ?>

<?php if(auth()->check() && auth()->user()->hasRole('super-admin')): ?>
<?php echo $__env->make('dashboard._super-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<?php if(auth()->check() && auth()->user()->hasRole('resepsionis')): ?>
 <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.resepsionis._resepsionis','data' => ['jadwal' => $jadwal,'datang' => $datang,'pasien' => $pasien,'appointments' => $appointments,'tindakan' => $tindakan,'periksa' => $periksa]]); ?>
<?php $component->withName('resepsionis._resepsionis'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['jadwal' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($jadwal),'datang' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($datang),'pasien' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($pasien),'appointments' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($appointments),'tindakan' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($tindakan),'periksa' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($periksa)]); ?> <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php endif; ?>



<?php if(auth()->check() && auth()->user()->hasRole('marketing')): ?>
<?php echo $__env->make('marketing.dashboard/index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<?php if(auth()->check() && auth()->user()->hasRole('supervisor')): ?>

<?php endif; ?>
<?php if(auth()->check() && auth()->user()->hasRole('hrd')): ?>
<?php echo $__env->make('hrd.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
<?php if(auth()->check() && auth()->user()->hasRole('logistik')): ?>
<?php echo $__env->make('logistik.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
<?php if(auth()->check() && auth()->user()->hasRole('purchasing')): ?>
<?php echo $__env->make('purchasing.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>


<?php $__env->stopSection(); ?>

<?php if(auth()->check() && auth()->user()->hasRole('resepsionis')): ?>
<?php $__env->startSection('footer'); ?>
<link rel=" stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/izitoast/1.4.0/css/iziToast.min.css" integrity="sha512-O03ntXoVqaGUTAeAmvQ2YSzkCvclZEcPQu1eqloPaHfJ5RuNGiS4l+3duaidD801P50J28EHyonCV06CUlTSag==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/izitoast/1.4.0/js/iziToast.min.js" integrity="sha512-Zq9o+E00xhhR/7vJ49mxFNJ0KQw1E1TMWkPTxrWcnpfEFDEXgUiwJHIKit93EW/XxE31HSI5GEOW06G6BF1AtA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

<script>
    $(document).ready(function() {

        $('.stts').on('click', function(e) {
            e.preventDefault();
            var form = this;
            Swal.fire({
                title: 'Ubah status pasien ?',
                text: "Apakah anda yakin ubah status pasien?",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes',
                cancelButtonText: 'No'
            }).then((result) => {
                if (result.isConfirmed) {
                    return form.submit();
                }
            })
        });
    })
</script>

<?php if(session('success')): ?>
<script>
    iziToast.success({
        title: 'Success',
        position: 'topRight',
        message: "<?php echo e(session('success')); ?>",
    });
</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php endif; ?>
<?php echo $__env->make('layouts.master', ['title' => 'Dashboard'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\yazfi\resources\views/dashboard/index.blade.php ENDPATH**/ ?>