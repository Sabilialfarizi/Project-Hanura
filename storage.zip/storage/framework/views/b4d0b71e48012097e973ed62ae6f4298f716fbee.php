<ul>
    <li class="menu-title">Main</li>
     <li class="<?php echo e(request()->is('/dashboard*') ? 'active' : ''); ?>">
        <a href="/dashboard"><i class="fa fa-dashboard"></i> <span>Dashboard</span>
        </a>
    </li>
    
    
    
    
    <li class="<?php echo e(request()->is('supervisor/komisi*') ? 'active' : ''); ?>">
        <a href="<?php echo e(route('supervisor.komisi.index')); ?>"><i class="fa fa-money"></i> <span>Komisi</span></a>
    </li>
    

     <li class="<?php echo e(request()->is('supervisor/cancel') ? 'active' : ''); ?>">
        <a href="<?php echo e(route('supervisor.cancel.index')); ?>"><i class="fa fa-money"></i> <span>Pembatalan</span></a>
    </li>




</ul>
<?php /**PATH C:\xampp\htdocs\yazfi\resources\views/components/supervisor/sidebar.blade.php ENDPATH**/ ?>