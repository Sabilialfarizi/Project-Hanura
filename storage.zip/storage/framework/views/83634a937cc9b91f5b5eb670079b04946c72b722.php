
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-sm-5 col-4">
        <h4 class="page-title">Show Purchase</h4>
    </div>
    
</div>
<div class="container">
    <div class="row">
        <div class="col-md-12 col-md-offset-10 body-main">
            <div class="col-md-12">
                <div class="card shadow" id="card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-4">
                                <div class="dashboard-logo">
                                    <img src="<?php echo e(url('/img/logo/yazfi.png ')); ?>" alt="Image" />
                                </div>
                            </div>
                            <div class="col-md-8 text-right">
                                <h6><strong>Fomulir:</strong></h6>
                                <input type="checkbox" />
                                <label style="font-size:.80em;">Material Delivered</label>
                            </div>
                        </div><br>
                        <div class="row">
                            <div class="col-md-12 text-center">
                                <h2><span class="purchase-order">Purchase Order</span></h2>
                            </div>
                        </div> <br />
                        
                        <div class="row">
                            <div class="col-md-12">
                                <div class="table-responsive">
                                    <table class="table table-bordered  report">
                                        <tr style="font-size:12px;" class="bg-success">
                                           
                                            <th class="text-light">No.</th>
                                            <th class="text-light">Description</th>
                                            <th class="text-light">Qty</th>
                                            <th class="text-light">Unit</th>
                                            <th class="text-light">Unit price</th>
                                            <th class="text-light">Total Price</th>
                                        </tr>
                                        <tbody>
                                            <?php
                                            $total = 0
                                            ?>
                                            <?php $__currentLoopData = App\Purchase::where('invoice', $purchase->invoice)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr style="font-size:12px;">
                                                
                                                <td><?php echo e($loop->iteration); ?></td>
                                                <td><?php echo e($barang->barang->nama_barang); ?></td>
                                               
                                                <td><?php echo e($barang->qty); ?></td>
                                            
                                                <td><?php echo e($barang->unit); ?></td>
                                                <td>Rp. <?php echo number_format($barang->harga_beli, 0, ',', '.'); ?></td>
                                                <td>Rp. <?php echo number_format($barang->total, 0, ',', '.'); ?></td>

                                            </tr>
                                            <?php
                                            $total += $barang->total
                                            ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                        <tfoot>
                                            <tr style="font-size:12px;">
                                                <td></td>
                                                <td colspan="3"></td>
                                                <td>SUB TOTAL </td>
                                                <td><b>Rp. <?php echo number_format($total, 0, ',', '.'); ?></b></td>
                                            </tr>
                                            <tr style="font-size:12px;">
                                                <td></td>
                                                <td colspan="3"></td>
                                                <td>PPN</td>
                                                <td><b><?php echo e($purchase->PPN); ?>%</b></td>
                                            </tr>
                                            <tr style="font-size:12px;">
                                                <td></td>
                                                <td colspan="3"></td>
                                                <td><strong>TOTAL<strong> </td>
                                                <td><b>Rp. <?php echo number_format($purchase->grand_total, 0, ',', '.'); ?></b></td>
                                            </tr>
                                            
                                        </tfoot>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

</html>
<script>
    function myFunction() {
        document.getElementById("demo").innerHTML = "YOU CLICKED ME!";
    }
    $('.report').DataTable({
        dom: 'Bfrtip',
        buttons: [{
                extend: 'copy',
                className: 'btn-default',
                exportOptions: {
                    columns: ':visible'
                }
            },
            {
                extend: 'excel',
                className: 'btn-default',
                title: 'Laporan Pembelian ',
                messageTop: 'Tanggal  <?php echo e(request("from")); ?> - <?php echo e(request("to")); ?>',
                footer: true,
                exportOptions: {
                    columns: ':visible'
                }
            },
            {
                extend: 'pdf',
                className: 'btn-default',
                title: 'Laporan Pembelian ',
                messageTop: 'Tanggal <?php echo e(request("from")); ?> - <?php echo e(request("to")); ?>',
                footer: true,
                exportOptions: {
                    columns: ':visible'
                }
            },
        ]
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', ['title' => 'Show Purchase'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\yazfi\resources\views/purchasing/listpurchase/show.blade.php ENDPATH**/ ?>