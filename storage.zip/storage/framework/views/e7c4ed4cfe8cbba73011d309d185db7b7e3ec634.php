

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-sm-4 col-3">
        <h4 class="page-title">Master Satuan Barang</h4>
    </div>
    <div class="col-sm-8 text-right m-b-20">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product-create')): ?>
        <a href="<?php echo e(route('admin.satuan.create')); ?>" class="btn btn btn-primary btn-rounded float-right"><i class="fa fa-plus"></i> Add Satuan Barang</a>
        <?php endif; ?>
    </div>
</div>

 <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.alert','data' => []]); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

<div class="row">
    <div class="col-sm-12">
        <div class="table-responsive">
            <table class="table table-bordered table-striped custom-table report">
                <thead>
                    <tr>
                        <th class="text-center" style="width:10px; ">No</th>
                        <th  class="text-center" style="width:200px; ">Nama</th>
                        
                        <th style="width: 50px;">Action</th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__currentLoopData = $satuan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $satuans): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="text-center"><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($satuans->nama); ?></td>
                        
                        <td>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product-edit')): ?>
                            <a href="<?php echo e(route('admin.satuan.edit', $satuans->id)); ?>" class="btn btn-sm btn-info"><i class="fa fa-edit"></i></a>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product-delete')): ?>
                            <form action="<?php echo e(route('admin.satuan.destroy', $satuans->id)); ?>" method="post" style="display: inline;" class="delete-form">
                                <?php echo method_field('DELETE'); ?>
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-sm btn-danger delete"><i class="fa fa-trash"></i></button>
                            </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>




<?php $__env->startSection('footer'); ?>
<script>
    $('.report').DataTable({
        dom: 'Bfrtip',
        buttons: [{
                extend: 'copy',
                className: 'btn-default',
                exportOptions: {
                    columns: ':visible'
                }
            },
            {
                extend: 'excel',
                className: 'btn-default',
                title: 'Laporan Satuan Barang',
                messageTop: 'Tanggal  <?php echo e(request("from")); ?> - <?php echo e(request("to")); ?>',
                footer: true,
                exportOptions: {
                    columns: ':visible'
                }
            },
            {
                extend: 'pdf',
                className: 'btn-default',
                title: 'Laporan Satuan Barang ',
                messageTop: 'Tanggal <?php echo e(request("from")); ?> - <?php echo e(request("to")); ?>',
                footer: true,
                exportOptions: {
                    columns: ':visible'
                }
            },
        ]
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', ['title' => 'Satuan Barang'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\yazfi\resources\views/admin/satuan/index.blade.php ENDPATH**/ ?>