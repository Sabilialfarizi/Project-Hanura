

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-sm-5 col-4">
        <h4 class="page-title">Invoice</h4>
    </div>
    <div class="col-sm-7 col-8 text-right m-b-30">
        <div class="btn-group btn-group-sm">
            <button class="btn btn-white">CSV</button>
            <button class="btn btn-white">PDF</button>
            <button class="btn btn-white"><i class="fa fa-print fa-lg"></i> Print</button>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-body">
                <div class="row custom-invoice">
                    <div class="col-6 col-sm-6 m-b-20">
                        <img src="<?php echo e(asset('/storage/' . \App\Setting::find(1)->logo)); ?>" class="inv-logo" alt="">
                        <ul class="list-unstyled">
                            <li><?php echo e(\App\Setting::find(1)->web_name); ?></li>
                            <li><?php echo e($appointment->cabang->nama); ?></li>
                            <li><?php echo e($appointment->cabang->alamat); ?></li>
                        </ul>
                    </div>
                    <div class="col-6 col-sm-6 m-b-20">
                        <div class="invoice-details">
                            <h3 class="text-uppercase"><?php echo e($appointment->no_booking); ?></h3>
                            <ul class="list-unstyled">
                                <li>Date booking: <span><?php echo e(Carbon\Carbon::parse($appointment->tanggal_status)->format('d/m/Y')); ?></span></li>
                                <li>No Rekam Medik: <span><?php echo e($appointment->pasien->rekam_medik); ?></span></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-6 col-lg-6 m-b-20">

                        <h5>Invoice to:</h5>
                        <ul class="list-unstyled">
                            <li>
                                <h5><strong><?php echo e($appointment->pasien->nama); ?></strong></h5>
                            </li>
                            <li><span><?php echo e($appointment->pasien->alamat); ?></span></li>
                            <?php
                            $age = explode(",", $appointment->pasien->ttl)
                            ?>
                            <li><?php echo e(\Carbon\Carbon::now()->format('Y') - \Carbon\Carbon::parse($appointment->pasien->tgl_lahir)->format('Y')); ?> Tahun</li>
                            <li><?php echo e($appointment->pasien->jk); ?></li>
                            <li><?php echo e($appointment->pasien->nik_ktp); ?></li>
                        </ul>

                    </div>
                    <?php
                    $pajak = $appointment->tindakan->sum('nominal') * $appointment->cabang->ppn / 100
                    ?>
                    <div class="col-sm-6 col-lg-6 m-b-20">
                        <div class="invoices-view">
                            <span class="text-muted">Payment Details:</span>
                            <ul class="list-unstyled invoice-payment-details">
                                <li>
                                    <h5>Total Due: <span class="text-right">Rp. <?php echo number_format($appointment->tindakan->sum('nominal') + $pajak, 0, ',', '.'); ?></span></h5>
                                </li>
                                <li>Perawat: <span data-toggle="modal" data-target="#perawatModal" id="perawat"><?php echo e($appointment->perawat->name ?? '-'); ?>

                                    </span></li>
                                <li>Office boy: <span data-toggle="modal" data-target="#obModal" id="ob"><?php echo e($appointment->ob->name ?? '-'); ?></span></li>
                                <li>Resepsionis: <span><?php echo e($appointment->resepsionis->name ?? '-'); ?></span></li>
                                <li>Address: <span><?php echo e($appointment->cabang->alamat); ?></span></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>ITEM</th>
                                <th>DESCRIPTION</th>
                                <th>UNIT COST</th>
                                <th>QUANTITY</th>
                                <th>TOTAL</th>
                                <th>STATUS</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $total = 0;
                            ?>
                            <?php $__currentLoopData = $appointment->tindakan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tindakan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($tindakan->item->nama_barang); ?></td>
                                <td><?php echo e($tindakan->item->description); ?></td>
                                <?php
                                $harga = \App\HargaProdukCabang::where('barang_id', $tindakan->item->id)->where('cabang_id', auth()->user()->cabang_id)->first();
                                ?>
                                <td>Rp. <?php echo number_format($harga->harga, 0, ',', '.'); ?></td>
                                <td><?php echo e($tindakan->qty); ?></td>
                                <td>Rp. <?php echo number_format($harga->harga * $tindakan->qty, 0, ',', '.'); ?></td>
                                <td><span class="custom-badge status-<?php echo e($tindakan->status == 0 ? 'red' : 'green'); ?>"><?php echo e($tindakan->status == 0 ? 'Belum' : 'Selesai'); ?></span></td>
                            </tr>
                            <?php
                            $total += $harga->harga * $tindakan->qty
                            ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <div>
                    <div class="row invoice-payment">
                        <div class="col-sm-7">
                        </div>
                        <div class="col-sm-12">
                            <div class="m-b-20">
                                <h6>Total due</h6>
                                <div class="table-responsive no-border">
                                    <table border="1" class="table mb-0">
                                        <tbody>
                                            <tr>
                                                <th>Subtotal:</th>
                                                <td class="text-right">Rp. <?php echo number_format($total, 0, ',', '.'); ?></td>
                                            </tr>
                                            <?php if($appointment->cabang->status_pajak == 1): ?>
                                            <tr>
                                                <th>Pajak (<?php echo e($appointment->cabang->ppn); ?>%):</th>
                                                <td class="text-right">
                                                    <?php
                                                    $pajak = $total * $appointment->cabang->ppn / 100
                                                    ?>
                                                    Rp. <?php echo number_format($pajak, 0, ',', '.'); ?>
                                                </td>
                                            </tr>
                                            <?php endif; ?>
                                            <tr>
                                                <th>Grand Total :</th>
                                                <td class="text-right">Rp. <?php echo number_format($total + $pajak, 0, ',', '.'); ?></td>
                                            </tr>
                                            <tr>
                                                <th>Dibayar:</th>
                                                <td class="text-right">Rp. <?php echo number_format($appointment->rincian->sum('dibayar') + $appointment->rincian->sum('disc_vouc'), 0, ',', '.'); ?></td>
                                            </tr>
                                            <tr>
                                                <th>Sisa Pembayaran:</th>
                                                <td class="text-right text-primary sisa" id="Rp. <?php echo number_format($total - $appointment->rincian->sum('dibayar') + $pajak, 0, ',', '.'); ?>">
                                                    <h5 class="tsisa">Rp. <?php echo number_format($total - $appointment->rincian->sum('dibayar') + $pajak - $appointment->rincian->sum('disc_vouc'), 0, ',', '.'); ?></h5>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="invoice-info">
                        <?php if($appointment->status_pembayaran == 0): ?>
                        <h5>Pembayaran</h5>
                        <p class="text-muted"></p>
                        <table width="519" border="0" class="table">
                            <tbody>
                                <tr>
                                    <td width="200">Metode Pembayaran</td>
                                    <td width="195">Nominal</td>
                                    <td width="195">Dibayar</td>
                                    <td width="195">Change</td>
                                    <td width="188">Waktu Pembayaran</td>
                                </tr>
                                <tr>
                                    <form action="<?php echo e(route('resepsionis.appointments.bayar')); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="booking_id" value="<?php echo e($appointment->id); ?>" id="booking_id">
                                        <input type="hidden" name="nominal" value="<?php echo e($total - $appointment->rincian->sum('dibayar') + $pajak); ?>" id="nml">
                                        <input type="hidden" name="bayar" value="" id="bayar">
                                        <input type="hidden" name="kembali" value="0" id="kembali">
                                        <input type="hidden" name="voucher_id" value="0" id="voucher_id">
                                        <input type="hidden" name="diskon" value="0" id="diskon">
                                        <td>
                                            <select name="payment" class="form-control" id="metode" required>
                                                <option selected disabled>-- Metode --</option>
                                                <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($payment->id); ?>"><?php echo e($payment->nama_metode); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>

                                            <?php $__errorArgs = ['payment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small class="text-danger"><?php echo e($message); ?></small>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </td>
                                        <td><input type="text" value="<?php echo number_format($total - $appointment->rincian->sum('dibayar') + $pajak - $appointment->rincian->sum('disc_vouc'), 0, ',', '.'); ?>" class="form-control" id="nominal"></td>
                                        <td><input type="text" value="0" class="form-control" id="dibayar"></td>
                                        <td><input type="text" value="0" class="form-control" id="change" readonly></td>
                                        <td><input type="datetime" value="<?php echo e(\Carbon\Carbon::now()->format('Y-m-d H:i')); ?>" class="form-control" name="tanggal_pembayaran" id="tanggal_pembayaran" readonly></td>
                                        <td><button type="submit" class="btn btn-success">Input</button></td>
                                    </form>
                                </tr>
                                <tr>
                                    <td height="47" id="potongan"></td>
                                    <td>&nbsp;</td>
                                    <td>&nbsp;</td>
                                    <td>&nbsp;</td>
                                    <td>&nbsp;</td>
                                    <td>&nbsp;</td>
                                </tr>
                            </tbody>
                        </table>
                        <table width="519" border="0" class="table table-voc">
                            <tbody>
                                <tr>
                                    <td width="200" height="47">Kode Voucher</td>
                                    <td></td>
                                </tr>
                                <tr class="voucher">
                                    <td><input type="text" class="form-control" id="voc" placeholder="Kode Voucher"></td>
                                    <td><button type="button" class="btn btn-success voc">Apply</button></td>
                                </tr>
                                <tr>
                                    <td id="voucher" colspan="2"></td>
                                </tr>
                            </tbody>
                        </table>
                        <?php endif; ?>

                        <p></p>
                        <table width="520" border="0" class="table">
                            <tbody>
                                <tr>
                                    <td>No</td>
                                    <td>Metode </td>
                                    <td>Waktu </td>
                                    <td>Cashier</td>
                                    <td>Potongan</td>
                                    <td>Nominal</td>
                                    <td>Biaya Kartu</td>
                                    <td>Diskon</td>
                                    <td>Dibayar</td>
                                </tr>
                                <?php $__currentLoopData = $appointment->rincian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rincian): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($rincian->payment->nama_metode); ?></td>
                                    <td><?php echo e(\Carbon\Carbon::parse($rincian->tanggal_pembayaran)->format('d/m/Y H:i')); ?></td>
                                    <td><?php echo e($rincian->kasir->name); ?></td>
                                    <td><?php echo e($rincian->payment->potongan); ?>%</td>
                                    <td>Rp. <?php echo number_format($rincian->nominal, 0, ',', '.'); ?></td>
                                    <td>Rp. <?php echo number_format($rincian->biaya_kartu, 0, ',', '.'); ?></td>
                                    <td>Rp. <?php echo number_format($rincian->disc_vouc, 0, ',', '.'); ?></td>
                                    <td>Rp. <?php echo number_format($rincian->dibayar, 0, ',', '.'); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/izitoast/1.4.0/css/iziToast.min.css" integrity="sha512-O03ntXoVqaGUTAeAmvQ2YSzkCvclZEcPQu1eqloPaHfJ5RuNGiS4l+3duaidD801P50J28EHyonCV06CUlTSag==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/izitoast/1.4.0/js/iziToast.min.js" integrity="sha512-Zq9o+E00xhhR/7vJ49mxFNJ0KQw1E1TMWkPTxrWcnpfEFDEXgUiwJHIKit93EW/XxE31HSI5GEOW06G6BF1AtA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script>
    $(document).ready(function() {
        $('#perawat').css('cursor', 'pointer');
        $('#ob').css('cursor', 'pointer');

        var dibayar = document.getElementById('dibayar');
        dibayar.addEventListener('keyup', function(e) {
            dibayar.value = formatRupiah(this.value, 'Rp. ');

            var nominal = parseInt($("#nominal").val().replace(/[^,\d]/g, ''));
            var bayar = parseInt(this.value.replace(/[^,\d]/g, ''))
            var change = bayar - nominal;
            $("#change").empty();

            if (bayar >= nominal) {
                $("#change").val(change)

                var kmb = document.getElementById('change');
                kmb.value = formatRupiah(kmb.value, "Rp. ")
            } else {
                $("#change").val(0);
                $("#kembali").val(0)
            }

            $("#bayar").val(bayar)

            voucher()
        });

        $(".voc").on('click', function() {
            voucher()
        })

        function voucher() {
            let kode_voucher = $("#voc").val();
            // let date = $("#tanggal_pembayaran").val()
            let dibayar = $("#bayar").val()
            let kembali = $("#kembali").val()
            let nominal = $("#nml").val();
            let booking_id = $("#booking_id").val()

            let route = "<?php echo e(route('resepsionis.appointments.voucher')); ?>";
            let _token = $('meta[name="csrf-token"]').attr('content');

            $("#voucher").empty()

            $.ajax({
                url: route,
                method: 'POST',
                dataType: 'JSON',
                data: {
                    kode_voucher: kode_voucher,
                    nominal: nominal,
                    kembali: kembali,
                    booking_id: booking_id,
                    dibayar: dibayar,
                    _token: _token
                },
                success: function(result) {
                    if (result.status == 400) {
                        $("#voucher").append(`<span class="text-danger">*` + result.message + `</span>`)
                    } else {
                        if (result.status) {
                            $(".sisa").empty().append(`<h5><s class="text-muted">Rp. ` + $("#nominal").val() + `</s> Rp. ` + result.sisa + `</h5>`);
                            $("#nominal").val(result.sisa)
                            $("#voucher").append(`<span class="text-success">*` + result.message + `</span>`)
                            $("#voucher_id").val(result.voucher_id)
                            $("#diskon").val(result.diskon)
                        } else {
                            $("#voucher").append(`<span>` + result.message + `</span>`)
                        }
                    }
                }
            })
        }

        function formatRupiah(angka, prefix) {
            var number_string = angka.replace(/[^,\d]/g, '').toString(),
                split = number_string.split(','),
                sisa = split[0].length % 3,
                rupiah = split[0].substr(0, sisa),
                ribuan = split[0].substr(sisa).match(/\d{3}/gi);

            // tambahkan titik jika yang di input sudah menjadi angka ribuan
            if (ribuan) {
                separator = sisa ? '.' : '';
                rupiah += separator + ribuan.join('.');
            }

            rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;
            return prefix == undefined ? rupiah : (rupiah ? rupiah : '');
        }




        $("#metode").on('change', function() {
            var id = $(this).val();
            let route = "/admin/payments/" + id;


            $.ajax({
                method: 'GET',
                url: route,
                success: function(result) {
                    $("#potongan").empty();

                    if (result.payment.potongan == 0) {
                        $("#potongan").append("Tidak ada potongan");
                    } else {
                        $("#potongan").append("Potongan Sebesar : " + result.payment.potongan + "%")
                    }

                }
            })
        })
    })
</script>

<?php if(session('success')): ?>
<script>
    iziToast.success({
        title: 'Success',
        position: 'topRight',
        message: "<?php echo e(session('success')); ?>",
    });
</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', ['title' => 'Appointment'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\yazfi\resources\views/admin/appointments/show.blade.php ENDPATH**/ ?>