
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-sm-5 col-4">
        <h4 class="page-title">Edit Penerimaan Barang</h4>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="card shadow" id="card">
            <div class="card-body">
                <div class="row custom-invoice">
                    <div class="col-sm-6 col-sg-4 m-b-4">
                        <div class="dashboard-logo">
                            <img src="<?php echo e(url('/img/logo/yazfi.png ')); ?>" alt="Image" />
                        </div>
                    </div>
                    <div class="col-sm-6 col-sg-4 m-b-4">
                        <div class="invoice-details">
                            <h3 class="text-uppercase"></h3>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-6 col-sg-4 m-b-4">
                        <h5>Invoice to:</h5>
                        <ul class="list-unstyled">
                            <li>
                                <h5><strong></strong></h5>
                            </li>
                            <li><span></span></li>
                        </ul>
                    </div>
                </div>
            
                <div class="row">
                    <div class="col-sm-6 col-sg-4 m-b-4">
                        <ul class="list-unstyled">
                            <li>
                                <div class="form-group">
                                    <label for="supplier">Supplier <span style="color: red">*</span></label>
                                    <input type="text" readonly class="form-control"
                                        value="<?php echo e($purchase->nama); ?>">
                                </div>
                            </li>
                        </ul>
                    </div>
                    <div class="col-sm-6 col-sg-4 m-b-4">
                        <ul class="list-unstyled">
                            <li>
                                <div class="form-group">
                                    <label for="project">Project <span style="color: red">*</span></label>
                                    <input type="text" value="<?php echo e($purchase->nama_project); ?> " class="form-control"
                                        readonly>
                                </div>
                            </li>
                        </ul>
                    </div>
                    <div class="col-sm-6 col-sg-4 m-b-4">
                        <ul class="list-unstyled">
                            <li>
                                <div class="form-group">
                                    <label for="lokasi">Lokasi <span style="color: red">*</span></label>
                                    <input type="text" value="<?php echo e($purchase->lokasi); ?>" class="form-control" readonly>
                                </div>
                            </li>
                        </ul>
                    </div>
                    <div class="col-sm-6 col-sg-4 m-b-4">
                        <ul class="list-unstyled">
                            <li>
                                <div class="form-group">
                                    <label for="tanggal">Tanggal <span style="color: red">*</span></label>
                                    <input type="text" value="<?php echo e($purchase->created_at); ?>" class="form-control" readonly>

                                </div>
                            </li>
                        </ul>
                    </div>

                </div>
                <?php $__currentLoopData = $penerimaans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <form action="<?php echo e(route('purchasing.penerimaan-barang.update', $purchase->id)); ?>" method="get">
                    <?php echo method_field('PATCH'); ?>
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-sm-6 col-sg-4 m-b-4">
                            <ul class="list-unstyled">
                                <li>
                                    <div class="form-group">
                                        <input type="hidden" readonly id="id_purchase" name="id_purchase" class="form-control"
                                            value="<?php echo e($item ? $item->id_purchase : ''); ?>">
                                    </div>
                                </li>
                            </ul>
                        </div>
                        <div class="col-sm-6 col-sg-4 m-b-4">
                            <ul class="list-unstyled">
                                <li>
                                    <div class="form-group">
                                        <input type="hidden" id="id_user" name="id_user" readonly class="form-control"
                                            value="<?php echo e(auth()->user()->id); ?>">
                                    </div>
                                </li>
                            </ul>
                        </div>
                        <br>
                        <div class="col-md-12">
                            <div class="row">
                                <div class="col-sm-6 col-sg-4 m-b-4">
                                    <ul class="list-unstyled">
                                        <li>
                                            <div class="form-group">
                                                <h4 class="page-title">Insert Penerimaan Barang</h4>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-6 col-sg-4 m-b-4">
                                    <ul class="list-unstyled">
                                        <li>
                                            <div class="form-group">
                                                <label for="tanggal">No Penerimaan Barang <span
                                                        style="color: red">*</span></label>
                                                <input type="text" id="no_penerimaan_barang" name="no_penerimaan_barang"
                                                    readonly class="form-control" value="<?php echo e($item ? $item->no_penerimaan_barang : ''); ?>">
                                        </li>
                                    </ul>
                                </div>
                                <div class="col-sm-6 col-sg-4 m-b-4">
                                    <ul class="list-unstyled">
                                        <li>
                                            <div class="form-group">
                                                <label for="tanggal_penerimaan">Tanggal Penerimaan Barang<span
                                                        style="color: red">*</span></label>
                                                <input type="datetime-local" id="tanggal_penerimaan"
                                                    name="tanggal_penerimaan" class="form-control" required=""  value="<?php echo e(Carbon\Carbon::parse($item ? $item->tanggal_penerimaan : '')->format('Y-m-d').'T'.Carbon\Carbon::parse($item ? $item->tanggal_penerimaan : '')->format('H:i:s')); ?>">
                                                <?php $__errorArgs = ['tanggal_penerimaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <small class="text-danger"><?php echo e($message); ?></small>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="table-responsive">
                                <table class="table table-bordered  report">
                                    <tr style="font-size:12px;" class="bg-success">
                                        <th class=" text-light">No.</th>
                                        <th class="text-light">Nama Barang</th>
                                        <th class="text-light">Qty Received</th>
                                        <th class="text-light">Qty Order</th>
                                        <th class="text-light">Harga Satuan</th>
                                        <th class="text-light"> Total</th>
                                        <th class="text-light"> Status Barang</th>
                                    </tr>
                                    <br>
                                    <br>
                                    <tbody id="dynamic_field">
                                        <script src="<?php echo e(asset('/')); ?>js/jquery-3.2.1.min.js"></script>
                                        <script src="<?php echo e(asset('/')); ?>js/select2.min.js"></script>

                                        <?php $__currentLoopData = $penerimaans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $penerimaan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="rowComponent">
                                            <td>
                                                <?php echo e($loop->iteration); ?>

                                            </td>
                                            <td>

                                                <input type="text" value="<?php echo e($penerimaan->barang->nama_barang); ?>"
                                                    class="form-control" disabled>
                                                <input type="hidden" name="barang_id[<?php echo e($loop->iteration); ?>]"
                                                    data="<?php echo e($loop->iteration); ?>" id="barang_id"
                                                    value="<?php echo e($penerimaan->barang_id); ?>"
                                                    class="form-control barang_id-<?php echo e($loop->iteration); ?>">

                                                <?php $__errorArgs = ['barang_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <small class="text-danger"><?php echo e($message); ?></small>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </td>
                                            <td>
                                                <input type="number" name="qty_received[<?php echo e($loop->iteration); ?>]" value="<?php echo e($penerimaan->qty_received); ?>"
                                                    class="form-control qty_received-<?php echo e($loop->iteration); ?>"
                                                    data="<?php echo e($loop->iteration); ?>" required="" onkeyup="testNum(this)"
                                                    id="qty_received" placeholder=" 0">

                                                <?php $__errorArgs = ['qty_received'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <small class="text-danger"><?php echo e($message); ?></small>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </td>
                                            <td>
                                                <input type="number" value="<?php echo e($penerimaan->qty); ?>"
                                                    name="qty[<?php echo e($loop->iteration); ?>]" data="<?php echo e($loop->iteration); ?>"
                                                    id="qty" class="form-control qty-<?php echo e($loop->iteration); ?>"
                                                    placeholder="0" required="">

                                                <?php $__errorArgs = ['qty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <small class="text-danger"><?php echo e($message); ?></small>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                            </td>
                                            <td>
                                                <input type="number" value="<?php echo e($penerimaan->harga_beli); ?>"
                                                    name="harga_beli[<?php echo e($loop->iteration); ?>]"
                                                    class="form-control harga_beli-<?php echo e($loop->iteration); ?>"
                                                    data="<?php echo e($loop->iteration); ?>"
                                                    onkeyup="hitung(this), HowAboutIt(this)" placeholder="0"
                                                    id="harga_beli" required="">

                                                <?php $__errorArgs = ['harga_beli'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <small class="text-danger"><?php echo e($message); ?></small>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </td>
                                            <td>
                                                <input type="number" value="<?php echo e($penerimaan->total); ?>"
                                                    name="total[<?php echo e($loop->iteration); ?>]" disabled
                                                    class="form-control total-<?php echo e($loop->iteration); ?> total-form"
                                                    placeholder="0" required="">

                                                <?php $__errorArgs = ['total'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <small class="text-danger"><?php echo e($message); ?></small>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </td>
                                            <td>
                                                <input type="text" value="<?php echo e($penerimaan->purchase->status_barang); ?>"
                                                    name="status_barang[<?php echo e($loop->iteration); ?>]" id="status_barang"
                                                    class="form-control status_barang-<?php echo e($loop->iteration); ?> status-form"
                                                    placeholder="Status Barang" required="">
                                                <?php $__errorArgs = ['status_barang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <small class="text-danger"><?php echo e($message); ?></small>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </td>

                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>

                                </table>
                                <div class="row invoice-payment">
                                    <div class="col-sm-4 offset-sm-8">

                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label>Total</label>
                                                    <input type="text" id="sub_total" name="total" readonly
                                                        class="form-control"
                                                        value="<?php echo e($penerimaans->sum('total')); ?>">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <script>
                                    function hitung(e) {
                                        let harga = e.value
                                        let attr = $(e).attr('data')
                                        let qty = $(`.qty-${attr}`).val()
                                        console.log(qty);
                                        let total = parseInt(harga * qty)
                                        $(`.total-${attr}`).val(total)

                                    }


                                    // function TotalAbout(e) {
                                    //     let sub_total = document.getElementById('sub_total')
                                    //     let total = 0;
                                    //     let coll = document.querySelectorAll('.total-form')
                                    //     for (let i = 0; i < coll.length; i++) {
                                    //         let ele = coll[i]
                                    //         total += parseInt(ele.value)
                                    //     }
                                    //     sub_total.value = total
                                    //     document.getElementById('grandtotal').value = total;
                                    // }

                                    function HowAboutIt(e) {
                                        let sub_total = document.getElementById('sub_total')
                                        let total = 0;
                                        let coll = document.querySelectorAll('.total-form')
                                        for (let i = 0; i < coll.length; i++) {
                                            let ele = coll[i]
                                            total += parseInt(ele.value)
                                        }
                                        sub_total.value = total
                                        // let SUB = document.getElementById('sub_total').value;
                                        // let PPN = document.getElementById('PPN').value;
                                        // console.log(PPN);
                                        // let tax = PPN / 100 * sub_total.value;
                                        // console.log(tax);
                                        // console.log(SUB);
                                        // let grand_total = parseInt(SUB) + parseInt(tax);
                                        // document.getElementById('grandtotal').value = grand_total;
                                        // console.log(grand_total);
                                    }

                                </script>

                                <div class="col-sm-1 offset-sm-8">
                                    <button type="submit" class="btn btn-primary" id="submit">Submit</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
                <div class="row">
                    <div class="col-md-12">
                        <div class="table-responsive">
                            <div class="row">
                                <div class="col-sm-5 col-4">
                                    <h4 class="page-title">Riwayat Penerimaan Barang</h4>
                                </div>
                            </div>
                            <table class="table table-bordered  report">
                                <tr style="font-size:12px;" class="bg-success">
                                    <th class=" text-light">No.</th>
                                    <th class="text-light">Nama Barang</th>
                                    <th class="text-light">Qty</th>
                                    <th class="text-light">Harga</th>
                                    <th class="text-light"> Total</th>
                                    <th class="text-light"> Diajukan</th>
                                </tr>
                                <tbody id="dynamic_field">
                                    <?php $__currentLoopData = $penerimaans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $penerimaan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="rowComponent">
                                        <td>
                                            <?php echo e($loop->iteration); ?>

                                        </td>
                                        <td>
                                            <?php echo e($penerimaan->barang->nama_barang); ?>

                                        </td>
                                        <td>
                                            <?php echo e($penerimaan->qty); ?>

                                        </td>
                                        <td>
                                            Rp. <?php echo number_format($penerimaan->harga_beli, 0, ',', '.'); ?>
                                        </td>
                                        <td>
                                            Rp. <?php echo number_format($penerimaan->total, 0, ',', '.'); ?>
                                        </td>
                                        <td>
                                            <?php echo e($penerimaan->admin->name); ?>

                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                  
            </div>
        </div>
    </div>
</div>


</html>
<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
<script>
    var formatter = function (num) {
        var str = num.toString().replace("", ""),
            parts = false,
            output = [],
            i = 13,
            formatted = null;
        if (str.indexOf(".") > 0) {
            parts = str.split(".");
            str = parts[0];
        }
        str = str.split("").reverse();
        for (var j = 0, len = str.length; j < len; j++) {
            if (str[j] != ",") {
                output.push(str[j]);
                if (i % 3 == 0 && j < (len - 1)) {
                    output.push(",");
                }
                i++;
            }
        }
        formatted = output.reverse().join("");
        return ("" + formatted + ((parts) ? "." + parts[1].substr(0, 2) : ""));
    };


    // document.getElementById('submit').disabled = true

    function form_dinamic() {
        let index = $('#dynamic_field tr').length + 1
        document.getElementById('counter').innerHTML = index
        // let template = `
        // <tr class="rowComponent">
        //             <td hidden>
        //                 <input type="hidden" name="barang_id[${index}]" class="barang_id-${index}">
        //             </td>
        //             <td>
        //                 <select required name="barang_id[${index}]" id="${index}" class="form-control select-${index}"></select>
        //             </td>
        //             <td>
        //                 <input type="number" name="qty[${index}]"  class="form-control qty-${index}" placeholder="0">
        //             </td>
        //             <td>
        //                 <input type="number" name="harga_beli[${index}]" class="form-control harga_beli-${index} waktu" placeholder="0"  data="${index}" onkeyup="hitung(this)">
        //             </td>
        //             <td>
        //                 <input type="number" name="total[${index}]" disabled class="form-control total-${index} total-form"  placeholder="0">
        //             </td>
        //             <td>
        //                 <button type="button" class="btn btn-danger btn-sm" onclick="remove(this)">Delete</button>
        //             </td>
        //         </tr>
        // `
        $('#dynamic_field').append(template)

        $(`.select-${index}`).select2({
            placeholder: 'Select Product',
            ajax: {
                url: `/admin/where/product`,
                processResults: function (data) {
                    console.log(data)
                    return {
                        results: data
                    };
                },
                cache: true
            }
        });


    }

    function remove(q) {
        $(q).parent().parent().remove()
    }
    $('.remove').on('click', function () {
        $(this).parent().parent().remove()
    })


    $(document).ready(function () {
        $('#add').on('click', function () {
            form_dinamic()
        })
    })
    $(document).ready(function () {
        $('.dynamic_function').change(function () {
            var invoice = $(this).val();
            var id = $(this).val();
            var div = $(this).parent();
            var op = " ";
            console.log(invoice);
            $.ajax({
                url: `/purchasing/where/penerimaan/search`,
                method: "get",
                data: {
                    'invoice': invoice,
                },
                success: function (data) {
                    console.log(data);
                    for (var i = 0; i < data.length; i++) {
                        var id = data[i].id;
                        // console.log(supplier_id);
                        document.getElementById('id').value = id;

                        // var supplier_id = data[i].supplier_id;
                        // // console.log(supplier_id);
                        // document.getElementById('supplier_id').value = supplier_id;
                        // document.getElementById('supplier_id').defaultvalue = supplier_id;

                        // var project_id = data[i].project_id;
                        // // console.log(project_id);
                        // document.getElementById('project_id').value = project_id;
                        // document.getElementById('project_id').defaultvalue = project_id;

                        // var lokasi = data[i].lokasi;
                        // // console.log(lokasi);
                        // document.getElementById('lokasi').value = lokasi;
                        // document.getElementById('lokasi').defaultvalue = lokasi;

                        // var created_at = data[i].created_at;
                        // // console.log(created_at);
                        // document.getElementById('created_at').value = created_at;
                        // document.getElementById('created_at').defaultvalue = created_at;


                    };
                },
                error: function () {}
            })
        })
    })

    function testNum(e) {
        let result = 0;
        let attr = $(e).attr('data')
        let qty_received = $(`.qty_received-${attr}`).val()
        console.log(qty_received)
        let qty = $(`.qty-${attr}`).val()
        console.log(qty)

        if (qty > qty_received) {
            result = 'partial'
        } else {
            result = 'completed';
        }

        $(`.status_barang-${attr}`).val(result)

        // console.log(status_barang);
        // let coll = document.querySelectorAll('.status-form')
        // for (let i = 0; i < coll.length; i++) {
        //     let ele = coll[i]
        //     status_barang += parseInt(ele.value)
        // }
        // document.getElementById("status_barang").value = result;

        // console.log(status_barang)


    }

    // function tesNumIT(e) {


    //     let status_barang = 0;
    //     let coll = document.querySelectorAll('.status-form')
    //     for (let i = 0; i < coll.length; i++) {
    //         let ele = coll[i]
    //         status_barang += parseInt(ele.value)
    //     }
    //     let SUB = document.getElementById(status_barang);

    // }

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', ['title' => 'Create Penerimaan Barang'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\yazfi\resources\views/purchasing/penerimaan-barang/edit.blade.php ENDPATH**/ ?>