<div class="row justify-content-left text-left">
    <div class="col-md-12">
        <div class="card shadow" id="card">
            <div class="card-body">

    
                        <div class="form-group">
                            <label for="id_sales">Nama Sales </label>
                            <select name="id_sales" id="id_sales" class="form-control select2" multiple="multiple">
                                
                                <?php $__currentLoopData = $staff_marketing; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($staff->id); ?>"><?php echo e($staff->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>

                            <?php $__errorArgs = ['id_sales'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label for="id_spv">Nama Spv</label>
                            <select name="id_spv" id="id_spv" class="form-control">
                                <option disabled selected>-- Select Nama SPV --</option>
                                <?php $__currentLoopData = $spv; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $spvs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                                <option 
                                    value="<?php echo e($spvs->id); ?>"><?php echo e($spvs->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>

                            <?php $__errorArgs = ['id_jabatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label for="id_manager">Nama Manager Marketing</label>
                            <select name="id_manager" required="" id="id_manager" class="form-control">
                                <option disabled selected>-- Select Nama Manager Marketing --</option>
                                <?php $__currentLoopData = $manager_marketing; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manager_marketings): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                                <option 
                                    value="<?php echo e($manager_marketings->id); ?>"><?php echo e($manager_marketings->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>

                            <?php $__errorArgs = ['id_manager'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

               

                <div class="m-t-20 text-center">
                    <button type="submit" class="btn btn-primary submit-btn"><i class="fa fa-save"></i> Save</button>
                </div>
            </div>
        </div>
    </div>
</div>

</html>
<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
<script>
    $(document).ready(function () {
        $('.dynamic').change(function () {
            var id = $(this).val();
            var div = $(this).parent();
            var op = "";
            $.ajax({
                url: `/hrd/where/project`,
                method: "get",
                data: {
                    'id': id
                },
                success: function (data) {
                    console.log(data);
                    for (var i = 0; i < data.length; i++) {
                        op += '<option value="' + data[i].nama_project + '">' + data[i]
                            .nama_project + '</option>'
                    };
                    $('.root1').html(op);
                },
                error: function () {

                }
            })
        })
    })

</script>
<?php /**PATH C:\xampp\htdocs\yazfi\resources\views/hrd/tim-sales/form.blade.php ENDPATH**/ ?>