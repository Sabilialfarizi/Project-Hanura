<ul>
    <li class="menu-title">Main</li>
    <li class="<?php echo e(request()->is('dashboard*') ? 'active' : ''); ?>">
        <a href="/dashboard"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a>
    </li>

    <li class="<?php echo e(request()->is('purchasing/listpruchase*') ? 'active' : ''); ?>">
        <a href="<?php echo e(route('purchasing.listpurchase.index')); ?>"><i class="fa-solid fa-list-check"></i><span>List Purchase</span></a>
    </li>

    <li class="<?php echo e(request()->is('purchasing/inputtukarfaktur*') ? 'active' : ''); ?>">
        <a href="<?php echo e(route('purchasing.tukarfaktur.index')); ?>"><i class="fa-solid fa-list-check"></i> <span>List Faktur</span></a>
    </li>
    <li class="<?php echo e(request()->is('purchasing/penerimaanbarang*') ? 'active' : ''); ?>">
        <a href="<?php echo e(route('purchasing.penerimaan-barang.index')); ?>"><i class="fa fa-cart-plus"></i> <span>Penerimaan Barang</span></a>
    </li>
    <li class="<?php echo e(request()->is('purchasing/reinburst*') ? 'active' : ''); ?>">
        <a href="<?php echo e(route('purchasing.reinburst.index')); ?>"><i class="fa-solid fa-hand-holding-dollar"></i> <span>Reinburst</span></a>
    </li>

</ul><?php /**PATH C:\xampp\htdocs\yazfi\resources\views/components/purchasing/sidebar.blade.php ENDPATH**/ ?>