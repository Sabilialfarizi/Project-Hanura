<div class="row">
    <div class="col-md-12">
        <div class="table-responsive">
            <table class="table table-striped table-bordered custom-table report" width="100%">
                <thead>
                    <tr>
                        <th style="text-align: center;">No</th>
                        <th>Nama Item</th>
                        <th>Supllier</th>
                        <th>Project</th>
                        <th>Warehouse</th>
                        
                       
                        <th>Waktu</th>
                        <th>Admin</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $barangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td style="text-align: center;"><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($barang->barang->nama_barang); ?></td>
                        <td><?php echo e($barang->supplier->nama ?? '-'); ?></td>
                        <td>
                            <?php if($barang->project_id): ?>
                            <?php echo e($barang->project->nama_project); ?>

                            <?php endif; ?>
                        </td>   
                        <td><?php echo e($barang->warehouse->nama_warehouse); ?></td>
                 
                        <td><?php echo e(Carbon\Carbon::parse($barang->created_at)->format('d/m/Y')); ?></td>
                        <td><?php echo e($barang->admin->name); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
         
            </table>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\yazfi\resources\views/admin/report/barang/table.blade.php ENDPATH**/ ?>