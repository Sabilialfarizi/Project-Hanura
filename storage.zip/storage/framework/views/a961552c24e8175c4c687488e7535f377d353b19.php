

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header d-flex flex-row justify-content-between">
                <a href="<?php echo e(url()->previous()); ?>" class="btn btn-sm btn-info">Back</a>
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('hrd.gaji.update',$penggajian->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('put'); ?>
                    <div class="row">
                        <div class="col-md-6">
                            <table class="table table-borderless">
                                <thead>
                                    <tr>
                                        <th colspan="3">Penggajian</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <th>Pegawai</th>
                                        <th>:</th>
                                        <th>
                                            <select name="pegawai" id="pegawai" class="form-control select2-ajax">
                                                <option value="<?php echo e($penggajian->pegawai->id); ?>">
                                                    <?php echo e($penggajian->pegawai->name); ?> -
                                                    <?php echo e($penggajian->pegawai->no_ktp); ?>

                                                </option>
                                            </select>
                                        </th>
                                    </tr>
                                    <tr>
                                        <th>Tanggal</th>
                                        <th>:</th>
                                        <th>
                                            <input name="tanggal" type="date" class="form-control"
                                                value="<?php echo e(Carbon\Carbon::parse($penggajian->tamggal)->format('Y-m-d')); ?>">
                                        </th>
                                    </tr>
                                    <tr>
                                        <th>Bulan dan Tahun</th>
                                        <th>:</th>
                                        <th>
                                            <input type="month"
                                                value="<?php echo e(Carbon\Carbon::parse($penggajian->bulan_tahun)->format("F/Y")); ?>"
                                                name="bulan_tahun" class="form-control">
                                        </th>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <div class="col-md-6">
                            <table class="table table-borderless">
                                <thead>
                                    <tr>
                                        <th>Pegawai</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <th>Divisi</th>
                                        <th>:</th>
                                        <th>

                                            <input type="text" name="roles"
                                                value="<?php echo e($penggajian->divisi); ?>" id="roles"
                                                class="form-control" readonly>
                                        </th>
                                    </tr>
                                    <tr>
                                        <th>Jabatan</th>
                                        <th>:</th>
                                        <th>

                                            <input type="text" name="jabatans" value="<?php echo e($penggajian->jabatan); ?>"
                                                id="jabatans" class="form-control" readonly>
                                        </th>
                                    </tr>
                                    <tr>
                                        <th>Nama Perusahaan</th>
                                        <th>:</th>
                                        <th>

                                            <input type="text" name="perusahaans" id="perusahaans"
                                                value="<?php echo e($penggajian->perusahaan); ?>" class="form-control" readonly>
                                        </th>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <table class="table table-borderless">
                                <thead>
                                    <tr>
                                        <th colspan="3">Penerimaan</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $penggajian->penerimaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $terima): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th><?php echo e($terima->nama); ?></th>
                                        <th>:</th>
                                        <th>
                                            <input type="text" onkeyup="penerimaan(this)"
                                                value="<?php echo e(number_format($terima->nominal)); ?>"
                                                name="penerimaan[<?php echo e($terima->nama); ?>]" class="form-control penerimaan">
                                        </th>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <th>Total Penerimaan</th>
                                        <th>:</th>
                                        <th>
                                            <input type="text" name="total_penerimaan" readonly
                                                value="<?php echo e(number_format($penggajian->penerimaan->sum('nominal'))); ?>"
                                                id="total_penerimaan" class="form-control">
                                        </th>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                        <div class="col-md-6">
                            <table class="table table-borderless">
                                <thead>
                                    <tr>
                                        <th colspan="3">Potongan</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $penggajian->potongan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $potong): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th><?php echo e($potong->nama); ?></th>
                                        <th>:</th>
                                        <th>
                                            <input type="text" onkeyup="potongan(this)"
                                                value="<?php echo e(number_format($potong->nominal)); ?>"
                                                name="potongan[<?php echo e($potong->nama); ?>]" class="form-control potongan">
                                        </th>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <th>Total Potongan</th>
                                        <th>:</th>
                                        <th>
                                            <input type="text" name="total_potongan" readonly
                                                value="<?php echo e(number_format($penggajian->potongan->sum('nominal'))); ?>"
                                                id="total_potongan" class="form-control">
                                        </th>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                        <div class="col-md-6">
                            <table class="table table-borderless">
                                <thead>
                                    <tr>
                                        <th colspan="3">Total</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <th>Total</th>
                                    <th>:</th>
                                    <th>
                                        <input type="text"
                                            value="<?php echo e(number_format($penggajian->penerimaan->sum('nominal') - $penggajian->potongan->sum('nominal'))); ?>"
                                            readonly name="total" id="total" class="form-control">
                                    </th>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-sm btn-success">Submit</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
<script>
    // function rupiah(e) {
    //     $(e).val(formatter($(e).val()))
    // }

    function WeCanSumSallary() {
        $('#total').val(parseFloat($('#total_penerimaan').val().replace(/,/g, '')) - parseFloat($(
            '#total_potongan').val().replace(/,/g, '')))
    }

    function potongan(e) {
        let total = 0;
        let coll = $('.potongan')
        for (let i = 0; i < $(coll).length; i++) {
            let ele = $(coll)[i]
            console.log($(ele).val())
            total += parseFloat($(ele).val().replace(/,/g, ''))
        }
        $('#total_potongan').val(total)
        WeCanSumSallary()
    }

    function penerimaan(e) {
        let total = 0;
        let coll = $('.penerimaan')
        for (let i = 0; i < $(coll).length; i++) {
            let ele = $(coll)[i]
            console.log($(ele).val())
            total += parseFloat($(ele).val().replace(/,/g, ''))
        }
        $('#total_penerimaan').val(total)
        WeCanSumSallary()
    }

</script>

<?php echo $__env->make('layouts.master', ['title' => 'Edit Gaji'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\yazfi\resources\views/hrd/gaji/edit.blade.php ENDPATH**/ ?>