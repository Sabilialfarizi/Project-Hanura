

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-sm-4 col-3">
        <h4 class="page-title">Edit Unit Rumah</h4>
    </div>
</div>

<form action="<?php echo e(route('admin.unit.update', $unit->id_unit_rumah)); ?>" method="post">
    <?php echo method_field('PATCH'); ?>
    <?php echo csrf_field(); ?>

    <?php echo $__env->make('admin.unit.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', ['title' => 'Unit Rumah'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\yazfi\resources\views/admin/unit/edit.blade.php ENDPATH**/ ?>